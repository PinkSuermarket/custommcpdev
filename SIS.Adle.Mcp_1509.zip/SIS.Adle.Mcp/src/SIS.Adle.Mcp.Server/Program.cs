using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.OpenApi;
using SIS.Adle.Mcp.Server.Api;
using SIS.Adle.Mcp.Server.Auth;
using SIS.Adle.Mcp.Server.Logging;
using SIS.Adle.Mcp.Server.Tools;

var builder = WebApplication.CreateBuilder(args);

// Append every log line to logs/mcp-yyyyMMdd.log (captures MCP tool exceptions).
builder.Logging.AddProvider(new FileLoggerProvider(Path.Combine(builder.Environment.ContentRootPath, "logs")));

// Trust the X-Forwarded-* headers from a local tunnel (ngrok) so the scheme/host
// seen by the app is the public https URL, not http://localhost.
builder.Services.Configure<ForwardedHeadersOptions>(o =>
{
    o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto | ForwardedHeaders.XForwardedHost;
    o.KnownIPNetworks.Clear();
    o.KnownProxies.Clear();
});

// --- Authentication --------------------------------------------------------
// One flag, Mcp:DevAutoLogin:
//   true  -> dev mode auto login: server signs itself in via ROPC, /mcp is open.
//   false -> OAuth2 resource server: /mcp validates bearer tokens against Mcp:AzureAdB2C.
// See Auth/McpAuthenticationExtensions.cs.
builder.AddMcpAuthentication();

builder.Services.AddHttpContextAccessor();

// ROPC auto-login client, used only when Mcp:DevAutoLogin = true.
builder.Services.AddHttpClient<IDevTokenService, DevTokenService>();

// Typed client for the downstream Advanced Labor Web API (tools call this).
builder.Services.AddHttpClient<AdvancedLaborClient>((sp, c) =>
{
    var baseUrl = sp.GetRequiredService<IConfiguration>().GetValue<string>("Mcp:AdvancedLaborApi:BaseUrl")
        ?? "https://dev-al-api.azurewebsites.net/";
    c.BaseAddress = new Uri(baseUrl.EndsWith('/') ? baseUrl : baseUrl + "/");
});

var devAutoLogin = builder.Configuration.GetValue<bool>("Mcp:DevAutoLogin");

// Debug HTTP surface: Swagger UI to drive the tools by hand and see full errors.
builder.Services.AddScoped<UserTools>();
builder.Services.AddScoped<TimesheetHourlyCostsTool>();
builder.Services.AddScoped<TimesheetFringesCostsTool>();
builder.Services.AddScoped<TimesheetDeductionsCostsTool>();
builder.Services.AddScoped<TimesheetErContributionsCostsTool>();
builder.Services.AddScoped<TimesheetCostsSummaryTool>();
builder.Services.AddScoped<TimesheetApprovalTools>();
builder.Services.AddHttpClient(); // IHttpClientFactory for the OAuth metadata shim
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o =>
{
    o.SwaggerDoc("v1", new() { Title = "SIS Advanced Labor MCP — debug", Version = "v1" });

    // Authorize button — paste a raw JWT (no "Bearer " prefix). Sent as Authorization: Bearer <token>.
    o.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Paste a raw access token (no 'Bearer ' prefix).",
    });
    o.AddSecurityRequirement(_ => new OpenApiSecurityRequirement
    {
        [new OpenApiSecuritySchemeReference("Bearer", null)] = new List<string>(),
    });
});

// --- MCP server -----------------------------------------------------------
// Streamable HTTP transport. One diagnostic tool only: get_user_details, which
// echoes the caller's token claims so login success can be verified end to end.
builder.Services
    .AddMcpServer(o =>
    {
        o.ServerInfo = new() { Name = "SIS Advanced Labor MCP", Version = "0.1.0" };
    })
    .WithHttpTransport()
    .WithTools<UserTools>()
    .WithTools<TimesheetHourlyCostsTool>()
    .WithTools<TimesheetFringesCostsTool>()
    .WithTools<TimesheetDeductionsCostsTool>()
    .WithTools<TimesheetErContributionsCostsTool>()
    .WithTools<TimesheetCostsSummaryTool>()
    .WithTools<TimesheetApprovalTools>();

var app = builder.Build();

app.UseForwardedHeaders();

// Debug Swagger UI at /swagger (drives the tools, shows full errors).
app.UseSwagger();
app.UseSwaggerUI(o =>
{
    o.SwaggerEndpoint("/swagger/v1/swagger.json", "debug v1");
    o.DocumentTitle = "SIS Advanced Labor MCP — debug";
});

app.UseAuthentication();
app.UseAuthorization();

// Unauthenticated liveness probe.
app.MapGet("/healthz", () => Results.Ok("ok")).AllowAnonymous();

app.MapControllers();

// Relay B2C OAuth metadata under this origin + stub DCR (no-op when DevAutoLogin = true).
app.MapOAuthMetadataShim();

// MCP endpoint. When Mcp:DevAutoLogin = false it requires a valid bearer token and
// serves /.well-known/oauth-protected-resource for discovery. When true the endpoint
// is open and the server supplies the identity itself via ROPC.
var mcp = app.MapMcp("/mcp");
if (devAutoLogin)
{
    app.Logger.LogWarning("Mcp:DevAutoLogin = true — /mcp is UNAUTHENTICATED; the server auto-signs-in via ROPC with hard-coded dev credentials. Local dev only.");
    mcp.AllowAnonymous();
}
else
{
    mcp.RequireAuthorization();
}

app.Run();
