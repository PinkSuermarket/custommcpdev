using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using ModelContextProtocol.AspNetCore.Authentication;
using ModelContextProtocol.Authentication;

namespace SIS.Adle.Mcp.Server.Auth;

/// <summary>
/// Wires MCP server authentication from the single <c>Mcp:DevAutoLogin</c> flag.
///
/// <para><b>DevAutoLogin = true</b> — dev mode auto login. No JWT validation is wired;
/// <c>/mcp</c> is left open (see Program.cs) and the server signs itself in via OAuth2
/// password grant (<see cref="DevTokenService"/>). Local development only.</para>
///
/// <para><b>DevAutoLogin = false</b> — the server is an OAuth2 <b>resource server</b>. It
/// validates the bearer token the MCP client obtained from Azure AD B2C
/// (<see cref="AzureAdB2COptions"/>) and publishes an RFC 9728 protected-resource metadata
/// document so the client can discover the authorization server and run auth-code + PKCE.</para>
/// </summary>
public static class McpAuthenticationExtensions
{
    public static WebApplicationBuilder AddMcpAuthentication(this WebApplicationBuilder builder)
    {
        var options = new McpServerOptions();
        builder.Configuration.GetSection(McpServerOptions.SectionName).Bind(options);
        builder.Services.Configure<McpServerOptions>(
            builder.Configuration.GetSection(McpServerOptions.SectionName));

        if (options.DevAutoLogin)
        {
            // Dev auto login: nothing to validate — the server mints its own token.
            builder.Services.AddAuthentication();
            builder.Services.AddAuthorization();
            return builder;
        }

        var b2c = options.AzureAdB2C;
        if (!b2c.IsComplete)
            throw new InvalidOperationException(
                "Mcp:AzureAdB2C (Instance, Domain, ClientId, SignedOutSignUpSignInPolicyId) is required when Mcp:DevAutoLogin is false.");

        builder.Services
            .AddAuthentication(o =>
            {
                o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                // Challenges go through the MCP handler so 401s carry the
                // WWW-Authenticate: Bearer resource_metadata="..." hint.
                o.DefaultChallengeScheme = McpAuthenticationDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(o =>
            {
                o.Authority = b2c.Authority;
                o.MetadataAddress = b2c.MetadataAddress;
                o.Audience = b2c.ClientId;
                o.RequireHttpsMetadata = b2c.RequireHttpsMetadata;
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = true,
                    ValidAudiences = [b2c.ClientId],
                    ValidateIssuer = true,
                    ValidIssuers = b2c.ValidIssuers is { Length: > 0 } ? b2c.ValidIssuers : null,
                    ValidateIssuerSigningKey = true,
                    RequireExpirationTime = true,
                    ValidateLifetime = true,
                    RequireSignedTokens = true,
                };
            })
            .AddMcp(o =>
            {
                o.ResourceMetadata = new ProtectedResourceMetadata
                {
                    Resource = options.ServerUrl,
                    // Point at THIS server's origin; OAuthMetadataEndpoints relays B2C's
                    // metadata there (B2C has no RFC 8414 endpoint of its own).
                    AuthorizationServers = { options.ServerUrl.TrimEnd('/') },
                };
                foreach (var scope in b2c.ScopesSupported)
                    o.ResourceMetadata.ScopesSupported.Add(scope);
            });

        builder.Services.AddAuthorization(o =>
        {
            o.FallbackPolicy = o.DefaultPolicy; // every endpoint requires auth unless it opts out
        });

        return builder;
    }
}
