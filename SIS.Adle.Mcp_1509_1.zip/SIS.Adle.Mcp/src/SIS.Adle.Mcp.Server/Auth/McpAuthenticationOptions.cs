namespace SIS.Adle.Mcp.Server.Auth;

/// <summary>
/// Strongly-typed view of the <c>Mcp</c> configuration section.
/// Bound in <see cref="McpAuthenticationExtensions.AddMcpAuthentication"/>.
/// </summary>
public sealed class McpServerOptions
{
    public const string SectionName = "Mcp";

    /// <summary>Public base URL this server is reachable at (used in the resource metadata document).</summary>
    public string ServerUrl { get; set; } = "https://localhost:7443";

    /// <summary>
    /// THE auth switch.
    /// <list type="bullet">
    /// <item><c>true</c>  — dev mode auto login: the server signs itself in via OAuth2 password
    /// grant (ROPC, see <see cref="DevToken"/>) and <c>/mcp</c> is left open. Local dev only.</item>
    /// <item><c>false</c> — the server is an OAuth2 resource server: <c>/mcp</c> requires a bearer
    /// token validated against <see cref="AzureAdB2C"/>; the MCP client does the interactive login.</item>
    /// </list>
    /// </summary>
    public bool DevAutoLogin { get; set; }

    /// <summary>Azure AD B2C settings used when <see cref="DevAutoLogin"/> is <c>false</c>.</summary>
    public AzureAdB2COptions AzureAdB2C { get; set; } = new();

    /// <summary>ROPC credentials used only when <see cref="DevAutoLogin"/> is <c>true</c>.</summary>
    public DevTokenOptions DevToken { get; set; } = new();

    /// <summary>Downstream Advanced Labor API the tools call. Bound from <c>Mcp:AdvancedLaborApi</c>.</summary>
    public AdvancedLaborApiOptions AdvancedLaborApi { get; set; } = new();
}

/// <summary>
/// Azure AD B2C resource-server settings. Mirrors the API's <c>AzureAdB2C</c> section
/// (Instance / Domain / ClientId / SignedOutSignUpSignInPolicyId).
/// </summary>
public sealed class AzureAdB2COptions
{
    /// <summary>e.g. https://advancedlabornonprod.b2clogin.com/ (trailing slash optional).</summary>
    public string Instance { get; set; } = string.Empty;

    /// <summary>e.g. advancedlabornonprod.onmicrosoft.com</summary>
    public string Domain { get; set; } = string.Empty;

    /// <summary>The API app's client id — the expected token audience.</summary>
    public string ClientId { get; set; } = string.Empty;

    /// <summary>The B2C user-flow / custom policy id, e.g. b2c_1a_customsignupsignin.</summary>
    public string SignedOutSignUpSignInPolicyId { get; set; } = string.Empty;

    /// <summary>Accepted issuers. Empty => validated from the authority's OIDC metadata.</summary>
    public string[] ValidIssuers { get; set; } = [];

    /// <summary>OAuth scopes advertised in the protected-resource metadata document.</summary>
    public string[] ScopesSupported { get; set; } = [];

    public bool RequireHttpsMetadata { get; set; } = true;

    /// <summary>{Instance}/{Domain}/{policy}/v2.0</summary>
    public string Authority =>
        $"{Instance.TrimEnd('/')}/{Domain}/{SignedOutSignUpSignInPolicyId}/v2.0";

    /// <summary>{Authority}/.well-known/openid-configuration</summary>
    public string MetadataAddress => $"{Authority}/.well-known/openid-configuration";

    public bool IsComplete =>
        !string.IsNullOrWhiteSpace(Instance) && !string.IsNullOrWhiteSpace(Domain) &&
        !string.IsNullOrWhiteSpace(ClientId) && !string.IsNullOrWhiteSpace(SignedOutSignUpSignInPolicyId);
}

public sealed class AdvancedLaborApiOptions
{
    /// <summary>Base URL of the Advanced Labor Web API (trailing slash optional).</summary>
    public string BaseUrl { get; set; } = "https://dev-al-api.azurewebsites.net/";

    /// <summary>Optional fallback for the <c>x-company</c> header when a tool call omits companyId.</summary>
    public int? DefaultCompanyId { get; set; }
}

/// <summary>ROPC (OAuth2 password grant) credentials for dev auto login.</summary>
public sealed class DevTokenOptions
{
    /// <summary>
    /// Optional. A bearer token pasted in directly (copied from the app / Swagger after login).
    /// When set it is used as-is and the ROPC fields are ignored — handy when the account is
    /// federated / MFA and ROPC can't be used.
    /// </summary>
    public string StaticToken { get; set; } = string.Empty;

    /// <summary>OAuth2 token endpoint (a B2C ROPC policy, e.g. .../B2C_1A_ROPC/oauth2/v2.0/token).</summary>
    public string TokenUrl { get; set; } = string.Empty;

    public string ClientId { get; set; } = string.Empty;
    public string Scope { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}
