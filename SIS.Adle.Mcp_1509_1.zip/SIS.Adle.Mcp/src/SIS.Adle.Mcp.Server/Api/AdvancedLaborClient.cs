using System.Net.Http.Headers;
using System.Text.Json;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Options;
using SIS.Adle.Mcp.Server.Auth;

namespace SIS.Adle.Mcp.Server.Api;

/// <summary>
/// Typed client for the Advanced Labor Web API. Attaches the bearer token
/// (request user's token if present, otherwise the dev ROPC token) and the
/// <c>x-company</c> header, mirroring what SIS.APS.WebApi's AuthorizationFilter expects.
/// </summary>
public sealed class AdvancedLaborClient
{
    private static readonly HashSet<string> CostSections =
        new(StringComparer.OrdinalIgnoreCase) { "hourly", "fringes", "deductions", "ercontributions", "summary" };

    private readonly HttpClient _http;
    private readonly IDevTokenService _devToken;
    private readonly IHttpContextAccessor _httpContext;
    private readonly AdvancedLaborApiOptions _opt;
    private readonly ILogger<AdvancedLaborClient> _log;

    public AdvancedLaborClient(
        HttpClient http,
        IDevTokenService devToken,
        IHttpContextAccessor httpContext,
        IOptions<McpServerOptions> options,
        ILogger<AdvancedLaborClient> log)
    {
        _http = http;
        _devToken = devToken;
        _httpContext = httpContext;
        _opt = options.Value.AdvancedLaborApi;
        _log = log;
    }

    public async Task<JsonElement> GetTimesheetCostsAsync(string section, TimesheetCostQuery query, int? companyId, CancellationToken ct)
    {
        if (!CostSections.Contains(section))
            throw new ArgumentException($"Unknown section '{section}'. Expected one of: {string.Join(", ", CostSections)}.", nameof(section));

        var path = $"api/timesheets/costs/{section.ToLowerInvariant()}";
        var url = QueryHelpers.AddQueryString(path, query.ToQueryString());

        using var req = new HttpRequestMessage(HttpMethod.Get, url);
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", await ResolveBearerAsync(ct));

        var company = companyId ?? _opt.DefaultCompanyId;
        if (company is { } c)
            req.Headers.TryAddWithoutValidation("x-company", c.ToString());

        using var resp = await _http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
        var body = await resp.Content.ReadAsStringAsync(ct);

        if (!resp.IsSuccessStatusCode)
        {
            var challenge = resp.Headers.WwwAuthenticate.ToString();
            _log.LogError("AL API {Method} {Url} -> {Status}. www-authenticate: {Challenge}. body: {Body}",
                "GET", url, (int)resp.StatusCode, challenge, Trim(body));
            var detail = !string.IsNullOrWhiteSpace(challenge) ? challenge
                       : !string.IsNullOrWhiteSpace(body) ? Trim(body)
                       : "(no body, no www-authenticate)";
            throw new HttpRequestException($"Advanced Labor API GET {path} returned {(int)resp.StatusCode}. {detail}");
        }

        if (string.IsNullOrWhiteSpace(body))
            return default;

        using var doc = JsonDocument.Parse(body);
        return doc.RootElement.Clone();
    }

    /// <summary>
    /// Generic authenticated call (adds the bearer + x-company header). Throws
    /// <see cref="HttpRequestException"/> with the status + body/challenge on a non-2xx.
    /// </summary>
    public async Task<(int Status, string Body)> SendAsync(
        HttpMethod method, string relativeUrl, object? jsonBody, int? companyId, CancellationToken ct)
    {
        using var req = new HttpRequestMessage(method, relativeUrl.TrimStart('/'));
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", await ResolveBearerAsync(ct));

        var company = companyId ?? _opt.DefaultCompanyId;
        if (company is { } c)
            req.Headers.TryAddWithoutValidation("x-company", c.ToString());

        if (jsonBody is not null)
            req.Content = new StringContent(
                JsonSerializer.Serialize(jsonBody), System.Text.Encoding.UTF8, "application/json");

        using var resp = await _http.SendAsync(req, HttpCompletionOption.ResponseContentRead, ct);
        var body = await resp.Content.ReadAsStringAsync(ct);

        if (!resp.IsSuccessStatusCode)
        {
            var challenge = resp.Headers.WwwAuthenticate.ToString();
            _log.LogError("AL API {Method} {Url} -> {Status}. www-authenticate: {Challenge}. body: {Body}",
                method.Method, relativeUrl, (int)resp.StatusCode, challenge, Trim(body));
            var detail = !string.IsNullOrWhiteSpace(challenge) ? challenge
                       : !string.IsNullOrWhiteSpace(body) ? Trim(body)
                       : "(no body, no www-authenticate)";
            throw new HttpRequestException(
                $"Advanced Labor API {method.Method} {relativeUrl} returned {(int)resp.StatusCode}. {detail}");
        }

        _log.LogInformation("AL API {Method} {Url} -> {Status}", method.Method, relativeUrl, (int)resp.StatusCode);
        return ((int)resp.StatusCode, body);
    }

    /// <summary>Authenticated GET that parses the JSON body.</summary>
    public async Task<JsonElement> GetJsonAsync(string relativeUrl, int? companyId, CancellationToken ct)
    {
        var (_, body) = await SendAsync(HttpMethod.Get, relativeUrl, null, companyId, ct);
        if (string.IsNullOrWhiteSpace(body)) return default;
        using var doc = JsonDocument.Parse(body);
        return doc.RootElement.Clone();
    }

    public sealed record RawResult(int Status, bool Ok, string ContentType, string? Challenge, string Body, string RequestUrl, string BearerSource, int? CompanyHeader, object? TokenInfo);

    private static object DescribeToken(string bearer)
    {
        try
        {
            var jwt = new Microsoft.IdentityModel.JsonWebTokens.JsonWebToken(bearer);
            string? C(string t) => jwt.Claims.FirstOrDefault(c => c.Type == t)?.Value;
            return new
            {
                length = bearer.Length,
                alg = jwt.Alg,
                kid = jwt.Kid,
                typ = jwt.Typ,
                aud = C("aud"),
                iss = C("iss"),
                tfp = C("tfp") ?? C("acr"),
                scp = C("scp"),
                azp = C("azp"),
                exp = C("exp"),
                expiresUtc = jwt.ValidTo == DateTime.MinValue ? null : jwt.ValidTo.ToString("O"),
                expired = jwt.ValidTo != DateTime.MinValue && jwt.ValidTo < DateTime.UtcNow,
            };
        }
        catch (Exception ex)
        {
            return new { length = bearer.Length, parseError = ex.Message, first20 = bearer.Length > 20 ? bearer[..20] : bearer };
        }
    }

    /// <summary>
    /// Fire a GET at a relative AL API url and return everything (status, headers, body)
    /// without throwing. For the debug Swagger surface.
    /// </summary>
    public async Task<RawResult> RawGetAsync(string relativeUrl, int? companyId, CancellationToken ct, string? bearerOverride = null)
    {
        using var req = new HttpRequestMessage(HttpMethod.Get, relativeUrl.TrimStart('/'));
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        var (bearer, source) = !string.IsNullOrWhiteSpace(bearerOverride)
            ? (bearerOverride.Replace("Bearer ", "", StringComparison.OrdinalIgnoreCase).Trim(), "explicit-override")
            : await ResolveBearerWithSourceAsync(ct);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);

        var company = companyId ?? _opt.DefaultCompanyId;
        if (company is { } c)
            req.Headers.TryAddWithoutValidation("x-company", c.ToString());

        using var resp = await _http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
        var body = await resp.Content.ReadAsStringAsync(ct);
        var challenge = resp.Headers.WwwAuthenticate.ToString();

        _log.LogInformation("AL API GET {Url} -> {Status}. challenge: {Challenge}. bytes: {Len}",
            new Uri(_http.BaseAddress!, relativeUrl.TrimStart('/')), (int)resp.StatusCode, challenge, body.Length);

        return new RawResult(
            (int)resp.StatusCode, resp.IsSuccessStatusCode,
            resp.Content.Headers.ContentType?.ToString() ?? "",
            string.IsNullOrWhiteSpace(challenge) ? null : challenge,
            body,
            new Uri(_http.BaseAddress!, relativeUrl.TrimStart('/')).ToString(),
            source, company, DescribeToken(bearer));
    }

    private async Task<(string bearer, string source)> ResolveBearerWithSourceAsync(CancellationToken ct)
    {
        var auth = _httpContext.HttpContext?.Request.Headers.Authorization.ToString();
        if (!string.IsNullOrWhiteSpace(auth) && auth.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            return (auth["Bearer ".Length..].Trim(), "request-authorization-header");
        if (_devToken.Enabled)
            return ((await _devToken.GetAsync(ct)).AccessToken, "dev-token-service");
        throw new InvalidOperationException("No bearer token: request carried none and Mcp:DevAutoLogin is false.");
    }

    private async Task<string> ResolveBearerAsync(CancellationToken ct)
    {
        // 1. token already on the incoming request (real OAuth path)
        var auth = _httpContext.HttpContext?.Request.Headers.Authorization.ToString();
        if (!string.IsNullOrWhiteSpace(auth) && auth.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            return auth["Bearer ".Length..].Trim();

        // 2. dev path — server fetched its own token
        if (_devToken.Enabled)
            return (await _devToken.GetAsync(ct)).AccessToken;

        throw new InvalidOperationException("No bearer token: request carried none and Mcp:DevAutoLogin is false.");
    }

    private static string Trim(string s) => s.Length > 600 ? s[..600] + "…" : s;
}
