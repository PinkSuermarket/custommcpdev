using System.Diagnostics;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SIS.Adle.Mcp.Server.Api;
using SIS.Adle.Mcp.Server.Auth;
using SIS.Adle.Mcp.Server.Tools;

namespace SIS.Adle.Mcp.Server.Debug;

/// <summary>
/// DEV ONLY. Plain HTTP surface (shown in Swagger UI at /swagger) to drive the MCP tools
/// by hand and see the FULL error — the MCP protocol otherwise collapses a tool exception
/// into "An error occurred invoking '...'". Every call is also written to logs/mcp-*.log.
/// </summary>
[ApiController]
[Route("debug")]
[AllowAnonymous]
[Produces("application/json")]
public sealed class DebugController : ControllerBase
{
    private readonly TimesheetHourlyCostsTool _hourlyTool;
    private readonly UserTools _userTools;
    private readonly TimesheetApprovalTools _approvalTools;
    private readonly TimesheetValidationTools _validationTools;
    private readonly AdvancedLaborClient _alClient;
    private readonly IDevTokenService _devToken;
    private readonly ILogger<DebugController> _log;

    public DebugController(
        TimesheetHourlyCostsTool hourlyTool,
        UserTools userTools,
        TimesheetApprovalTools approvalTools,
        TimesheetValidationTools validationTools,
        AdvancedLaborClient alClient,
        IDevTokenService devToken,
        ILogger<DebugController> log)
    {
        _hourlyTool = hourlyTool;
        _userTools = userTools;
        _approvalTools = approvalTools;
        _validationTools = validationTools;
        _alClient = alClient;
        _devToken = devToken;
        _log = log;
    }

    /// <summary>validate_timesheets_for_approval — read-only pre-flight check, never mutates.</summary>
    [HttpPost("validate_timesheets_for_approval")]
    public Task<IActionResult> ValidateTimesheetsForApproval([FromBody] ValidateTimesheetsRequest req, CancellationToken ct) =>
        Run("validate_timesheets_for_approval", () => _validationTools.ValidateTimesheetsForApproval(req.TimesheetIds ?? [], req.CompanyId, ct));

    /// <summary>change_timesheet_status — approve/reject one timesheet (PATCH .../change-status).</summary>
    [HttpPost("change_timesheet_status")]
    public Task<IActionResult> ChangeTimesheetStatus([FromBody] ChangeStatusRequest req, CancellationToken ct) =>
        Run("change_timesheet_status", () => _approvalTools.ChangeTimesheetStatus(req.TimesheetId, req.Status, req.CompanyId, ct));

    /// <summary>create_timesheet_batch_job — queue a batch status change for many timesheets.</summary>
    [HttpPost("create_timesheet_batch_job")]
    public Task<IActionResult> CreateTimesheetBatchJob([FromBody] CreateBatchRequest req, CancellationToken ct) =>
        Run("create_timesheet_batch_job", () => _approvalTools.CreateTimesheetBatchJob(
            req.CurrentStatus, req.TimesheetIds ?? [], req.DoCalculation, req.IsExpenseEnabled, req.CompanyId, ct));

    /// <summary>get_timesheet_batch_job — one status check for a batch job.</summary>
    [HttpGet("get_timesheet_batch_job/{jobId:int}")]
    public Task<IActionResult> GetTimesheetBatchJob(int jobId, [FromQuery] int? companyId, CancellationToken ct) =>
        Run("get_timesheet_batch_job", () => _approvalTools.GetTimesheetBatchJob(jobId, companyId, ct));

    /// <summary>wait_timesheet_batch_job — poll a batch job until it finishes or times out.</summary>
    [HttpGet("wait_timesheet_batch_job/{jobId:int}")]
    public Task<IActionResult> WaitTimesheetBatchJob(int jobId, [FromQuery] int maxWaitSeconds = 60,
        [FromQuery] int pollIntervalSeconds = 3, [FromQuery] int? companyId = null, CancellationToken ct = default) =>
        Run("wait_timesheet_batch_job", () => _approvalTools.WaitTimesheetBatchJob(jobId, maxWaitSeconds, pollIntervalSeconds, companyId, null, ct));

    /// <summary>Claims of the token the server will use (dev ROPC / StaticToken), plus raw JWT.</summary>
    [HttpGet("dev-token")]
    public async Task<IActionResult> DevToken(CancellationToken ct)
    {
        if (!_devToken.Enabled)
            return Ok(new { enabled = false, message = "Mcp:DevAutoLogin is false." });

        try
        {
            var t = await _devToken.GetAsync(ct);
            return Ok(new
            {
                enabled = true,
                expiresOn = t.ExpiresOn,
                claims = t.Jwt.Claims.GroupBy(c => c.Type).ToDictionary(g => g.Key, g => g.Select(c => c.Value).ToArray()),
                rawToken = t.AccessToken,
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "debug/dev-token failed");
            return Problem(title: "dev-token failed", detail: ex.ToString(), statusCode: 500);
        }
    }

    /// <summary>Invoke get_user_details exactly as the MCP tool does.</summary>
    [HttpPost("get_user_details")]
    public async Task<IActionResult> GetUserDetails(CancellationToken ct) => await Run("get_user_details", () => _userTools.GetUserDetails(ct));

    /// <summary>Invoke get_timesheet_hourly_costs exactly as the MCP tool does. Body mirrors its params.</summary>
    [HttpPost("get_timesheet_hourly_costs")]
    public async Task<IActionResult> GetTimesheetHourlyCosts([FromBody] GetTimesheetCostsRequest req, CancellationToken ct) =>
        await Run("get_timesheet_hourly_costs", () => _hourlyTool.GetTimesheetHourlyCosts(
            req.CompanyId, req.IncludeRaw, req.StartDate, req.EndDate, req.WorkerId, req.WorkerIds, req.ProjectIds,
            req.TimesheetId, req.TimesheetIds, req.DefaultProjectId, req.PositionPayCycleId, req.TimesheetStatus,
            req.StatusValues, req.ExceptionCriteriaId, req.HasExceptionCriteria, req.ShowAll, req.SearchTerm,
            req.PageIndex ?? 0, req.PageSize ?? 25, req.SortProperty, req.SortDirection, ct));

    /// <summary>
    /// Direct GET api/timesheets/costs/hourly — no tool projection. Returns status,
    /// www-authenticate, body and which token was used. Use this to isolate the hourly bug.
    /// </summary>
    [HttpGet("hourly")]
    public async Task<IActionResult> Hourly(
        [FromQuery] int? companyId,
        [FromQuery] string? startDate,
        [FromQuery] string? endDate,
        [FromQuery] int? workerId,
        [FromQuery] string? workerIds,
        [FromQuery] string? projectIds,
        [FromQuery] int? timesheetId,
        [FromQuery] string? timesheetStatus,
        [FromQuery] bool? showAll,
        [FromQuery] int pageIndex = 0,
        [FromQuery] int pageSize = 50,
        [FromQuery] string? sortProperty = null,
        [FromQuery] string? sortDirection = null,
        [FromQuery(Name = "additionalSorts")] string? additionalSorts = null,
        [FromQuery(Name = "extraQuery")] string? extraQuery = null,
        [FromQuery(Name = "bearerOverride")] string? bearerOverride = null,
        [FromHeader(Name = "X-AL-Token")] string? xAlToken = null,
        CancellationToken ct = default)
    {
        var q = new List<KeyValuePair<string, string?>>
        {
            new("PageIndex", pageIndex.ToString()),
            new("PageSize", pageSize.ToString()),
        };
        void Add(string k, string? v) { if (!string.IsNullOrWhiteSpace(v)) q.Add(new(k, v)); }
        Add("StartDate", startDate); Add("EndDate", endDate);
        Add("WorkerId", workerId?.ToString()); Add("WorkerIds", workerIds); Add("ProjectIds", projectIds);
        Add("TimesheetId", timesheetId?.ToString()); Add("TimesheetStatus", timesheetStatus);
        Add("ShowAll", showAll?.ToString().ToLowerInvariant());
        Add("SortProperty", sortProperty); Add("SortDirection", sortDirection);
        Add("additionalSorts", additionalSorts);

        var url = Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString("api/timesheets/costs/hourly", q);
        if (!string.IsNullOrWhiteSpace(extraQuery))
            url += (url.Contains('?') ? "&" : "?") + extraQuery.TrimStart('?', '&');

        var sw = Stopwatch.StartNew();
        try
        {
            var token = !string.IsNullOrWhiteSpace(xAlToken) ? xAlToken : bearerOverride;
            var r = await _alClient.RawGetAsync(url, companyId, ct, token);
            _log.LogInformation("debug/hourly -> {Status} in {Ms}ms", r.Status, sw.ElapsedMilliseconds);
            return Ok(new
            {
                requestUrl = r.RequestUrl,
                bearerSource = r.BearerSource,
                xCompany = r.CompanyHeader,
                tokenInfo = r.TokenInfo,
                status = r.Status,
                ok = r.Ok,
                contentType = r.ContentType,
                wwwAuthenticate = r.Challenge,
                durationMs = sw.ElapsedMilliseconds,
                body = TryJson(r.Body),
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "debug/hourly threw in {Ms}ms", sw.ElapsedMilliseconds);
            return Ok(new { ok = false, exceptionType = ex.GetType().FullName, message = ex.Message, detail = ex.ToString() });
        }
    }

    private static object? TryJson(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        try { return JsonSerializer.Deserialize<JsonElement>(s); }
        catch { return s.Length > 2000 ? s[..2000] + "…" : s; }
    }

    /// <summary>Call the Advanced Labor API endpoint directly (no tool projection) and dump the raw result / error.</summary>
    [HttpGet("raw/{section}")]
    public async Task<IActionResult> Raw(string section, [FromQuery] int? companyId, [FromQuery] string? startDate,
        [FromQuery] string? endDate, [FromQuery] int? pageSize, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            var q = new TimesheetCostQuery
            {
                StartDate = DateOnly.TryParse(startDate, out var s) ? s : null,
                EndDate = DateOnly.TryParse(endDate, out var e) ? e : null,
                PageSize = section == "summary" ? null : pageSize ?? 50,
            };
            var json = await _alClient.GetTimesheetCostsAsync(section, q, companyId, ct);
            _log.LogInformation("debug/raw/{Section} OK in {Ms}ms", section, sw.ElapsedMilliseconds);
            return Content(json.GetRawText(), "application/json");
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "debug/raw/{Section} failed in {Ms}ms", section, sw.ElapsedMilliseconds);
            return Problem(title: $"raw/{section} failed", detail: ex.ToString(), statusCode: 502);
        }
    }

    private async Task<IActionResult> Run(string name, Func<Task<object>> invoke)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            var result = await invoke();
            _log.LogInformation("debug tool {Tool} OK in {Ms}ms", name, sw.ElapsedMilliseconds);
            return Ok(new { ok = true, tool = name, durationMs = sw.ElapsedMilliseconds, result });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "debug tool {Tool} threw in {Ms}ms", name, sw.ElapsedMilliseconds);
            return Ok(new
            {
                ok = false,
                tool = name,
                durationMs = sw.ElapsedMilliseconds,
                exceptionType = ex.GetType().FullName,
                message = ex.Message,
                inner = ex.InnerException?.Message,
                detail = ex.ToString(),
            });
        }
    }
}

/// <summary>Body for POST /debug/get_timesheet_costs — same fields as the MCP tool.</summary>
public sealed class GetTimesheetCostsRequest
{
    public string Section { get; set; } = "summary";
    public int? CompanyId { get; set; }
    public bool IncludeRaw { get; set; }
    public string? StartDate { get; set; }
    public string? EndDate { get; set; }
    public int? TimesheetId { get; set; }
    public int? WorkerId { get; set; }
    public string? WorkerIds { get; set; }
    public string? ProjectIds { get; set; }
    public int? DefaultProjectId { get; set; }
    public int? PositionPayCycleId { get; set; }
    public string? TimekeeperGroupIds { get; set; }
    public string? TimesheetStatus { get; set; }
    public string? StatusValues { get; set; }
    public string? TimesheetIds { get; set; }
    public int? ExceptionCriteriaId { get; set; }
    public bool? HasExceptionCriteria { get; set; }
    public string? ExceptionEditedByUserName { get; set; }
    public bool? ShowAll { get; set; }
    public bool? IsUnionTimesheet { get; set; }
    public bool? OnPayDate { get; set; }
    public bool? ActiveInAL { get; set; }
    public bool? ExcludeDraftTimesheet { get; set; }
    public int? InterCompanyId { get; set; }
    public string? SearchTerm { get; set; }
    public int? PageIndex { get; set; }
    public int? PageSize { get; set; }
    public string? SortProperty { get; set; }
    public string? SortDirection { get; set; }
}

/// <summary>Body for POST /debug/change_timesheet_status.</summary>
public sealed class ChangeStatusRequest
{
    public int TimesheetId { get; set; }
    public string Status { get; set; } = "Approved";
    public int? CompanyId { get; set; }
}

/// <summary>Body for POST /debug/create_timesheet_batch_job.</summary>
public sealed class CreateBatchRequest
{
    public string CurrentStatus { get; set; } = "Processed";
    public int[]? TimesheetIds { get; set; }
    public bool DoCalculation { get; set; }
    public bool IsExpenseEnabled { get; set; }
    public int? CompanyId { get; set; }
}

/// <summary>Body for POST /debug/validate_timesheets_for_approval.</summary>
public sealed class ValidateTimesheetsRequest
{
    public int[]? TimesheetIds { get; set; }
    public int? CompanyId { get; set; }
}
