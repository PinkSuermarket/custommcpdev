using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Server;
using SIS.Adle.Mcp.Server.Api;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>
/// Worker lookup — two separate tools by design. get_all_workers (GET api/workers) is a
/// searchable list; get_worker_details (GET api/workers/{id}) is one worker's full record.
/// If you only have a worker's NAME, you must call get_all_workers first to resolve their
/// id, then call get_worker_details with that id as a second, separate tool call — never
/// guess an id. Neither tool ever returns the worker's social security number.
/// </summary>
[McpServerToolType]
public sealed class WorkerTools(AdvancedLaborClient client)
{
    [McpServerTool(Name = "get_all_workers")]
    [Description("""
        Search/list workers (GET api/workers). Use this FIRST whenever you only have a
        worker's name (or no id at all) — search by name via searchTerm, find their id in
        the results, then call get_worker_details with that id as a SEPARATE tool call to
        get full details. Does not include social security number. Returns { totalCount, count, rows }.
        """)]
    public async Task<object> GetAllWorkers(
        [Description("Search by name, personnel number, etc.")] string? searchTerm = null,
        [Description("Filter to active-in-Advanced-Labor workers only when true, inactive only when false.")] bool? activeInAL = null,
        [Description("Worker status filter, e.g. Active, Terminated.")] string? status = null,
        [Description("Comma-separated timekeeper group ids.")] string? timekeeperGroupIds = null,
        [Description("Pay cycle id.")] int? payCycleId = null,
        [Description("Zero-based page index.")] int pageIndex = 0,
        [Description("Page size 1-300 (default 25).")] int pageSize = 25,
        [Description("Company id for the x-company header. Omit to use the signed-in user's remembered company or the server default.")] int? companyId = null,
        CancellationToken ct = default)
    {
        if (pageSize is < 1 or > 300)
            return new { error = "pageSize must be between 1 and 300." };

        var q = new List<string> { $"PageIndex={pageIndex}", $"PageSize={pageSize}" };
        void Add(string k, string? v) { if (!string.IsNullOrWhiteSpace(v)) q.Add($"{k}={Uri.EscapeDataString(v)}"); }
        Add("SearchTerm", searchTerm);
        Add("Status", status);
        Add("TimekeeperGroupIds", timekeeperGroupIds);
        if (activeInAL is { } a) q.Add($"ActiveInAL={a.ToString().ToLowerInvariant()}");
        if (payCycleId is { } pc) q.Add($"PayCycleId={pc}");

        var root = await client.GetJsonAsync($"api/workers?{string.Join('&', q)}", companyId, ct);
        var data = root.ValueKind == JsonValueKind.Object && root.TryGetProperty("data", out var d) && d.ValueKind == JsonValueKind.Array ? d : default;
        int? totalCount = root.ValueKind == JsonValueKind.Object && root.TryGetProperty("totalCount", out var tc) && tc.TryGetInt32(out var n) ? n : null;

        var rows = new List<object>();
        if (data.ValueKind == JsonValueKind.Array)
            foreach (var w in data.EnumerateArray())
                rows.Add(Project(w));

        return new { totalCount, count = rows.Count, rows };
    }

    [McpServerTool(Name = "get_worker_details")]
    [Description("""
        Full detail for ONE worker by id (GET api/workers/{id}). If you only have a name,
        call get_all_workers first to find the id, then call this tool separately — do not
        guess an id. Does not include social security number.
        """)]
    public async Task<object> GetWorkerDetails(
        [Description("The worker id (from get_all_workers).")] int workerId,
        [Description("Company id for the x-company header. Omit to use the signed-in user's remembered company or the server default.")] int? companyId = null,
        CancellationToken ct = default)
    {
        if (workerId <= 0)
            return new { error = "workerId must be a positive integer." };

        var root = await client.GetJsonAsync($"api/workers/{workerId}", companyId, ct);
        if (root.ValueKind != JsonValueKind.Object)
            return new { error = $"Worker {workerId} was not found." };

        return new
        {
            id = Int(root, "id"),
            personnelNumber = Str(root, "personnelNumber"),
            fullName = Str(root, "fullName"),
            status = CostJson.Enum(root, "status"),
            activeInAL = Bool(root, "activeInAL"),
            originalHireDate = Str(root, "originalHireDate"),
            terminationDate = Str(root, "terminationDate"),
            payrollEndDate = Str(root, "payrollEndDate"),
            title = Str(root, "title"),
            primaryEmail = Str(root, "primaryEmail"),
            timekeeperGroupId = Int(root, "timekeeperGroupId"),
            exemptFromOvertime = Bool(root, "exemptFromOvertime"),
        };
    }

    // Shared row projection for the list — deliberately omits socialSecurityNumber and address.
    private static object Project(JsonElement w) => new
    {
        id = Int(w, "id"),
        personnelNumber = Str(w, "personnelNumber"),
        fullName = Str(w, "fullName"),
        status = CostJson.Enum(w, "status"),
        activeInAL = Bool(w, "activeInAL"),
        originalHireDate = Str(w, "originalHireDate"),
    };

    private static string? Str(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    private static int? Int(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v) && v.TryGetInt32(out var n) ? n : null;

    private static bool? Bool(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v)
            ? v.ValueKind switch { JsonValueKind.True => true, JsonValueKind.False => false, _ => null }
            : null;
}
