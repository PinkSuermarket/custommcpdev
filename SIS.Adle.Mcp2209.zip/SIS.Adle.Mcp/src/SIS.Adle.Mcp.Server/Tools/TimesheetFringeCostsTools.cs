using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Server;
using SIS.Adle.Mcp.Server.Api;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>
/// Fringe-cost inquiry lines. <c>fringes</c> and <c>deductions</c> hit the same API service
/// and share one row shape (FringeCostInquiryOutput) — the controller sets the cost type
/// server-side from the path segment, so these are two thin tools over one projection.
/// </summary>
[McpServerToolType]
public sealed class TimesheetFringesCostsTool(AdvancedLaborClient client)
{
    [McpServerTool(Name = "get_timesheet_fringes_costs")]
    [Description("Fringe cost lines from the Advanced Labor Timesheet Cost Inquiry " +
                "(GET api/timesheets/costs/fringes). Returns { totalCount, count, rows }. All filters optional.")]
    public Task<object> Get(
        int? companyId = null, bool includeRaw = false,
        [Description("Inclusive start date, yyyy-MM-dd.")] string? startDate = null,
        [Description("Inclusive end date, yyyy-MM-dd.")] string? endDate = null,
        [Description("Single worker id.")] int? workerId = null,
        [Description("Comma-separated worker ids.")] string? workerIds = null,
        [Description("Comma-separated project ids.")] string? projectIds = null,
        [Description("Single timesheet id.")] int? timesheetId = null,
        [Description("Comma-separated timesheet ids.")] string? timesheetIds = null,
        [Description("Timesheet status: Draft|Rejected|Processed|Approved|Completed|StatementCreated|Void.")] string? timesheetStatus = null,
        [Description("Comma-separated status names.")] string? statusValues = null,
        [Description("Exception criteria id.")] int? exceptionCriteriaId = null,
        [Description("true = only rows with an exception criteria, false = only without.")] bool? hasExceptionCriteria = null,
        [Description("Include all rows regardless of default filtering.")] bool? showAll = null,
        [Description("Free-text search term.")] string? searchTerm = null,
        [Description("Zero-based page index.")] int pageIndex = 0,
        [Description("Page size 1-300 (default 25).")] int pageSize = 25,
        [Description("Property name to sort by.")] string? sortProperty = null,
        [Description("Asc | Desc.")] string? sortDirection = null,
        CancellationToken ct = default) =>
        FringeCosts.RunAsync(client, "fringes", companyId, includeRaw, startDate, endDate, workerId, workerIds,
            projectIds, timesheetId, timesheetIds, timesheetStatus, statusValues, exceptionCriteriaId,
            hasExceptionCriteria, showAll, searchTerm, pageIndex, pageSize, sortProperty, sortDirection, ct);
}

[McpServerToolType]
public sealed class TimesheetDeductionsCostsTool(AdvancedLaborClient client)
{
    [McpServerTool(Name = "get_timesheet_deductions_costs")]
    [Description("Deduction cost lines from the Advanced Labor Timesheet Cost Inquiry " +
                "(GET api/timesheets/costs/deductions). Same row shape as fringes. Returns { totalCount, count, rows }.")]
    public Task<object> Get(
        int? companyId = null, bool includeRaw = false,
        [Description("Inclusive start date, yyyy-MM-dd.")] string? startDate = null,
        [Description("Inclusive end date, yyyy-MM-dd.")] string? endDate = null,
        [Description("Single worker id.")] int? workerId = null,
        [Description("Comma-separated worker ids.")] string? workerIds = null,
        [Description("Comma-separated project ids.")] string? projectIds = null,
        [Description("Single timesheet id.")] int? timesheetId = null,
        [Description("Comma-separated timesheet ids.")] string? timesheetIds = null,
        [Description("Timesheet status: Draft|Rejected|Processed|Approved|Completed|StatementCreated|Void.")] string? timesheetStatus = null,
        [Description("Comma-separated status names.")] string? statusValues = null,
        [Description("Exception criteria id.")] int? exceptionCriteriaId = null,
        [Description("true = only rows with an exception criteria, false = only without.")] bool? hasExceptionCriteria = null,
        [Description("Include all rows regardless of default filtering.")] bool? showAll = null,
        [Description("Free-text search term.")] string? searchTerm = null,
        [Description("Zero-based page index.")] int pageIndex = 0,
        [Description("Page size 1-300 (default 25).")] int pageSize = 25,
        [Description("Property name to sort by.")] string? sortProperty = null,
        [Description("Asc | Desc.")] string? sortDirection = null,
        CancellationToken ct = default) =>
        FringeCosts.RunAsync(client, "deductions", companyId, includeRaw, startDate, endDate, workerId, workerIds,
            projectIds, timesheetId, timesheetIds, timesheetStatus, statusValues, exceptionCriteriaId,
            hasExceptionCriteria, showAll, searchTerm, pageIndex, pageSize, sortProperty, sortDirection, ct);
}

internal static class FringeCosts
{
    public static async Task<object> RunAsync(
        AdvancedLaborClient client, string section, int? companyId, bool includeRaw,
        string? startDate, string? endDate, int? workerId, string? workerIds, string? projectIds,
        int? timesheetId, string? timesheetIds, string? timesheetStatus, string? statusValues,
        int? exceptionCriteriaId, bool? hasExceptionCriteria, bool? showAll, string? searchTerm,
        int pageIndex, int pageSize, string? sortProperty, string? sortDirection, CancellationToken ct)
    {
        if (pageSize is < 1 or > 300)
            return new { error = "pageSize must be between 1 and 300." };

        var query = new TimesheetCostQuery
        {
            StartDate = DateOnly.TryParse(startDate, out var s) ? s : null,
            EndDate = DateOnly.TryParse(endDate, out var e) ? e : null,
            WorkerId = workerId,
            WorkerIds = workerIds,
            ProjectIds = projectIds,
            TimesheetId = timesheetId,
            TimesheetIds = timesheetIds,
            TimesheetStatus = timesheetStatus,
            StatusValues = statusValues,
            ExceptionCriteriaId = exceptionCriteriaId,
            HasExceptionCriteria = hasExceptionCriteria,
            ShowAll = showAll,
            SearchTerm = searchTerm,
            PageIndex = pageIndex,
            PageSize = pageSize,
            SortProperty = sortProperty,
            SortDirection = sortDirection,
        };

        var root = await client.GetTimesheetCostsAsync(section, query, companyId, ct);
        var data = CostJson.Data(root);
        var totalCount = CostJson.TotalCount(root);

        if (includeRaw)
            return new { totalCount, count = data.ValueKind == JsonValueKind.Array ? data.GetArrayLength() : 0, rows = data };

        var rows = new List<object>();
        if (data.ValueKind == JsonValueKind.Array)
            foreach (var r in data.EnumerateArray())
                rows.Add(new
                {
                    worker = CostJson.Str(r, "worker"),
                    personnelNumber = CostJson.Str(r, "personnelNumber"),
                    companyCode = CostJson.Str(r, "companyCode"),
                    date = CostJson.Str(r, "date"),
                    projectCode = CostJson.Str(r, "projectCode"),
                    projectName = CostJson.Str(r, "projectName"),
                    projectCompanyCode = CostJson.Str(r, "projectCompanyCode"),
                    paygroupCode = CostJson.Str(r, "paygroupCode"),
                    jobClassCode = CostJson.Str(r, "jobClassCode"),
                    jobClassName = CostJson.Str(r, "jobClassName"),
                    unionCode = CostJson.Str(r, "unionCode"),
                    unionName = CostJson.Str(r, "unionName"),
                    fringeCode = CostJson.Str(r, "fringeCode"),
                    unionAgreementCode = CostJson.Str(r, "unionAgreementCode"),
                    unionReciprocityCode = CostJson.Str(r, "unionReciprocityCode"),
                    fringeCalcMethod = CostJson.Enum(r, "fringeCalcMethod"),
                    fringeClassification = CostJson.Enum(r, "fringeClassification"),
                    projectCategoryCode = CostJson.Str(r, "projectCategoryCode"),
                    projectCategoryName = CostJson.Str(r, "projectCategoryName"),
                    fringeAmount = CostJson.Num(r, "fringeAmount"),
                    editedFringeAmount = CostJson.Num(r, "editedFringeAmount"),
                    source = CostJson.Enum(r, "source"),
                    actualSource = CostJson.Str(r, "actualSource"),
                    exceptionCriteriaCode = CostJson.Str(r, "exceptionCriteriaCode"),
                    exceptionCriteriaName = CostJson.Str(r, "exceptionCriteriaName"),
                    exceptionEditedBy = CostJson.Str(r, "exceptionEditedBy"),
                    activityCode = CostJson.Str(r, "activityCode"),
                    timesheetId = CostJson.Num(r, "timesheetId"),
                    timesheetFringeCostId = CostJson.Num(r, "timesheetFringeCostId"),
                });

        return new { totalCount, count = rows.Count, rows };
    }
}
