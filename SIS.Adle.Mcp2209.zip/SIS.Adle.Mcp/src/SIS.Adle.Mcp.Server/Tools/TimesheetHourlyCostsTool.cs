using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Server;
using SIS.Adle.Mcp.Server.Api;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>
/// get_timesheet_hourly_costs — GET api/timesheets/costs/hourly on the Advanced Labor API.
/// Template for the other sections (fringes / deductions / ercontributions / summary):
/// copy this file, change the path segment and the projected fields.
/// API response shape is { "data": [ ... ], "totalCount": n } (camelCase).
/// </summary>
[McpServerToolType]
public sealed class TimesheetHourlyCostsTool
{
    private readonly AdvancedLaborClient _client;

    public TimesheetHourlyCostsTool(AdvancedLaborClient client) => _client = client;

    [McpServerTool(Name = "get_timesheet_hourly_costs")]
    [Description("Hourly labor cost lines from the Advanced Labor Timesheet Cost Inquiry " +
                "(GET api/timesheets/costs/hourly). Returns { totalCount, count, rows }. " +
                "All filters optional. Set includeRaw=true for the full unabridged API rows.")]
    public async Task<object> GetTimesheetHourlyCosts(
        [Description("Company id for the x-company header (one of the user's authorized companies). Omit to use the server default.")] int? companyId = null,
        [Description("Return the full API rows instead of the curated projection.")] bool includeRaw = false,
        [Description("Inclusive start date, yyyy-MM-dd.")] string? startDate = null,
        [Description("Inclusive end date, yyyy-MM-dd.")] string? endDate = null,
        [Description("Single worker id.")] int? workerId = null,
        [Description("Comma-separated worker ids.")] string? workerIds = null,
        [Description("Comma-separated project ids.")] string? projectIds = null,
        [Description("Single timesheet id.")] int? timesheetId = null,
        [Description("Comma-separated timesheet ids.")] string? timesheetIds = null,
        [Description("Default project id.")] int? defaultProjectId = null,
        [Description("Position pay cycle id.")] int? positionPayCycleId = null,
        [Description("Timesheet status: Draft|Rejected|Processed|Approved|Completed|StatementCreated|Void.")] string? timesheetStatus = null,
        [Description("Comma-separated status names (alternative to timesheetStatus).")] string? statusValues = null,
        [Description("Exception criteria id.")] int? exceptionCriteriaId = null,
        [Description("true = only rows with an exception criteria, false = only without.")] bool? hasExceptionCriteria = null,
        [Description("Include all rows regardless of default filtering.")] bool? showAll = null,
        [Description("Free-text search term.")] string? searchTerm = null,
        [Description("Zero-based page index.")] int pageIndex = 0,
        [Description("Page size 1-300 (default 25).")] int pageSize = 25,
        [Description("Property name to sort by.")] string? sortProperty = null,
        [Description("Asc | Desc.")] string? sortDirection = null,
        CancellationToken ct = default)
    {
        if (pageSize is < 1 or > 300)
            return new { error = "pageSize must be between 1 and 300." };

        var query = new TimesheetCostQuery
        {
            StartDate = DateOnly.TryParse(startDate, out var s) ? s : null,
            EndDate = DateOnly.TryParse(endDate, out var e) ? e : null,
            WorkerId = workerId,
            WorkerIds = workerIds,
            ProjectIds = projectIds,
            TimesheetId = timesheetId,
            TimesheetIds = timesheetIds,
            DefaultProjectId = defaultProjectId,
            PositionPayCycleId = positionPayCycleId,
            TimesheetStatus = timesheetStatus,
            StatusValues = statusValues,
            ExceptionCriteriaId = exceptionCriteriaId,
            HasExceptionCriteria = hasExceptionCriteria,
            ShowAll = showAll,
            SearchTerm = searchTerm,
            PageIndex = pageIndex,
            PageSize = pageSize,
            SortProperty = sortProperty,
            SortDirection = sortDirection,
        };

        var root = await _client.GetTimesheetCostsAsync("hourly", query, companyId, ct);

        var data = root.ValueKind == JsonValueKind.Object && root.TryGetProperty("data", out var d) && d.ValueKind == JsonValueKind.Array
            ? d : default;
        int? totalCount = root.ValueKind == JsonValueKind.Object && root.TryGetProperty("totalCount", out var tc) && tc.TryGetInt32(out var n)
            ? n : null;

        if (includeRaw)
            return new { totalCount, count = data.ValueKind == JsonValueKind.Array ? data.GetArrayLength() : 0, rows = data };

        var rows = new List<object>();
        if (data.ValueKind == JsonValueKind.Array)
            foreach (var r in data.EnumerateArray())
                rows.Add(new
                {
                    worker = Str(r, "worker"),
                    personnelNumber = Str(r, "personnelNumber"),
                    companyCode = Str(r, "companyCode"),
                    date = Str(r, "date"),
                    projectCode = Str(r, "projectCode"),
                    projectName = Str(r, "projectName"),
                    projectTaskCode = Str(r, "projectTaskCode"),
                    paygroupCode = Str(r, "paygroupCode"),
                    jobClassCode = Str(r, "jobclassCode"),
                    jobClassName = Str(r, "jobClassName"),
                    earningCode = Str(r, "earningCode"),
                    totalHours = Num(r, "totalHours"),
                    regularHours = Num(r, "regularHours"),
                    overtimeHours = Num(r, "overtimeHours"),
                    doubleTimeHours = Num(r, "doubleTimeHours"),
                    tripleTimeHours = Num(r, "tripleTimeHours"),
                    hourlyRate = Num(r, "hourlyRate"),
                    calculatedCost = Num(r, "calculatedCost"),
                    calculatedProjectCost = Num(r, "calculatedProjectCost"),
                    editedHourlyRate = Num(r, "editedHourlyRate"),
                    timesheetStatus = Enum(r, "timesheetStatus"),
                    source = Enum(r, "source"),
                    costSource = Enum(r, "costSource"),
                    exceptionEditedBy = Str(r, "exceptionEditedBy"),
                    timesheetId = Num(r, "timesheetId"),
                    timesheetHourlyCostId = Num(r, "timesheetHourlyCostId"),
                });

        return new { totalCount, count = rows.Count, rows };
    }

    private static string? Str(JsonElement e, string prop) =>
        e.TryGetProperty(prop, out var v) && v.ValueKind is not (JsonValueKind.Null or JsonValueKind.Undefined)
            ? (v.ValueKind == JsonValueKind.String ? v.GetString() : v.ToString())
            : null;

    private static decimal? Num(JsonElement e, string prop) =>
        e.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.Number && v.TryGetDecimal(out var d) ? d : null;

    // EnumItemOutput serialises as { "id": "..", "description": ".." }; sometimes a plain string.
    private static string? Enum(JsonElement e, string prop)
    {
        if (!e.TryGetProperty(prop, out var v)) return null;
        return v.ValueKind switch
        {
            JsonValueKind.String => v.GetString(),
            JsonValueKind.Object => v.TryGetProperty("description", out var desc) && desc.ValueKind == JsonValueKind.String ? desc.GetString()
                                  : v.TryGetProperty("id", out var id) ? id.ToString() : null,
            _ => null,
        };
    }
}
