using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Server;
using SIS.Adle.Mcp.Server.Api;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>
/// Read-only pre-flight check for approving timesheets (Processed -&gt; Approved via
/// PATCH api/timesheets/{id}/change-status). Re-derives the same predicates
/// SIS.APS.Core.Timesheets.TimesheetsService.ChangeStatus enforces server-side, from data
/// already visible on GET responses, so a caller can see every reason an approval would
/// fail before attempting it (or before running create_timesheet_batch_job).
///
/// This tool NEVER calls change-status, batchjobs, or any endpoint that mutates state —
/// it only issues GET requests via AdvancedLaborClient.GetJsonAsync.
/// </summary>
[McpServerToolType]
public sealed class TimesheetValidationTools(AdvancedLaborClient client)
{
    private const int MaxConcurrency = 4;

    [McpServerTool(Name = "validate_timesheets_for_approval")]
    [Description("""
        Read-only pre-flight check for whether one or more timesheets can be approved
        (Processed -> Approved). Re-checks, from GET data only, every rule the real
        PATCH api/timesheets/{id}/change-status endpoint enforces server-side — this tool
        NEVER calls change-status or any batch job, it only reads. Returns every failing
        rule per timesheet (not just the first), plus informational warnings for two checks
        the public API doesn't expose (authorization, duplicate hourly costs) — those are
        never treated as failures, only flagged as unverified. Use this before calling
        create_timesheet_batch_job so failures can be explained to the user up front.
        """)]
    public async Task<object> ValidateTimesheetsForApproval(
        [Description("Timesheet ids to validate, e.g. [33433, 33435]. Duplicates and non-positive ids are dropped.")] int[] timesheetIds,
        [Description("Company id for the x-company header. Omit to use the server default.")] int? companyId = null,
        CancellationToken ct = default)
    {
        var ids = (timesheetIds ?? []).Where(id => id > 0).Distinct().ToArray();
        if (ids.Length == 0)
            return new { error = "timesheetIds must contain at least one positive id." };

        // Fetched once per invocation, shared by every timesheet.
        JsonElement systemParams;
        bool overtimeRulesEnabled;
        int? regularEarningCodeId;
        try
        {
            systemParams = await client.GetJsonAsync("api/systemparameters", companyId, ct);
            overtimeRulesEnabled = Bool(Get(systemParams, "timeSheets", "general", "enableOvertimeRules")) ?? true;
            regularEarningCodeId = Int(Get(systemParams, "timeSheets", "setup", "regularEarningCodeId"));
        }
        catch (Exception ex)
        {
            return new { error = $"Could not load system parameters (api/systemparameters): {ex.Message}. Overtime-rule validation cannot proceed without this." };
        }

        var payPeriodCache = new Dictionary<int, JsonElement>();
        var projectCache = new Dictionary<int, JsonElement>();
        var results = new object[ids.Length];

        await Parallel.ForEachAsync(
            Enumerable.Range(0, ids.Length),
            new ParallelOptions { MaxDegreeOfParallelism = MaxConcurrency, CancellationToken = ct },
            async (i, innerCt) =>
            {
                results[i] = await ValidateOneAsync(ids[i], companyId, overtimeRulesEnabled, regularEarningCodeId,
                    payPeriodCache, projectCache, innerCt);
            });

        var typed = results.Cast<Dictionary<string, object?>>().ToList();
        var validCount = typed.Count(r => (bool)r["canApprove"]!);

        return new
        {
            valid = validCount == typed.Count,
            requestedCount = timesheetIds?.Length ?? 0,
            validatedCount = typed.Count,
            validCount,
            invalidCount = typed.Count - validCount,
            results = typed,
        };
    }

    private async Task<Dictionary<string, object?>> ValidateOneAsync(
        int timesheetId, int? companyId, bool overtimeRulesEnabled, int? regularEarningCodeId,
        Dictionary<int, JsonElement> payPeriodCache, Dictionary<int, JsonElement> projectCache, CancellationToken ct)
    {
        var errors = new List<object>();
        var warnings = new List<object>();
        var sourceCalls = new List<string> { "GET api/systemparameters" };
        void Err(string code, string message, object? details = null) =>
            errors.Add(details is null ? new { code, message } : new { code, message, details });
        void Warn(string code, string message) => warnings.Add(new { code, message });

        JsonElement ts;
        sourceCalls.Add($"GET api/timesheets/{timesheetId}");
        try
        {
            ts = await client.GetJsonAsync($"api/timesheets/{timesheetId}", companyId, ct);
            if (ts.ValueKind != JsonValueKind.Object)
            {
                Err("timesheet-not-found", $"Timesheet {timesheetId} was not found.");
                return Result(timesheetId, null, errors, warnings, sourceCalls);
            }
        }
        catch (Exception ex)
        {
            Err("timesheet-not-found", $"Timesheet {timesheetId} could not be loaded: {ex.Message}");
            return Result(timesheetId, null, errors, warnings, sourceCalls);
        }

        var currentStatus = CostJson.Enum(ts, "status");
        var workerLines = Arr(ts, "workerlines");
        var expenseLines = Arr(ts, "expenseLines");

        // 1. worker active in AL
        var worker = Get(ts, "worker");
        if (Bool(Get(worker, "activeInAL")) == false)
            Err("worker-not-active-in-al", "Worker is not active in Advanced Labor.");

        // 2. worker not terminated before a non-zero-hours line date
        //    Worker.WorkerEndDate = PayrollEndDate ?? TerminationDate (SIS-APS Workers/Worker.cs)
        var workerEndDateStr = Str(Get(worker, "payrollEndDate")) ?? Str(Get(worker, "terminationDate"));
        if (DateTime.TryParse(workerEndDateStr, out var workerEndDate))
        {
            var badLines = workerLines
                .Where(l => LineTotalHours(l, overtimeRulesEnabled) != 0
                            && DateTime.TryParse(Str(Get(l, "date")), out var d) && d.Date > workerEndDate.Date)
                .Select(l => new { lineId = Int(Get(l, "id")), date = Str(Get(l, "date")) })
                .ToList();
            if (badLines.Count > 0)
                Err("worker-terminated", "The worker was terminated before one or more timesheet entries.", new { workerEndDate = workerEndDateStr, lines = badLines });
        }

        // 3. void
        if (string.Equals(currentStatus, "Void", StringComparison.OrdinalIgnoreCase))
            Err("void-timesheet", "The status of a Void timesheet cannot be changed.");

        // 4. pay period open
        var payPeriod = Get(ts, "payPeriod");
        var payPeriodId = Int(Get(payPeriod, "id"));
        var payPeriodStatus = Str(Get(payPeriod, "status"));
        if (payPeriodStatus is null && payPeriodId is { } ppid)
        {
            if (!payPeriodCache.TryGetValue(ppid, out payPeriod))
            {
                sourceCalls.Add($"GET api/payperiods/{ppid}");
                try { payPeriod = await client.GetJsonAsync($"api/payperiods/{ppid}", companyId, ct); payPeriodCache[ppid] = payPeriod; }
                catch { /* leave payPeriodStatus null -> treated as unknown, not closed */ }
            }
            payPeriodStatus = Str(Get(payPeriod, "status"));
        }
        if (string.Equals(payPeriodStatus, "Closed", StringComparison.OrdinalIgnoreCase))
            Err("pay-period-closed", "The pay period is closed.");

        // 5. authorization — not verifiable from public read APIs; the real call still enforces it.
        Warn("authorization-not-verified",
            "Timesheet update authorization cannot be verified by this read-only tool; the actual change-status call will enforce it.");

        // 6. all worker-line projects enabled
        var disabledProjects = new List<object>();
        foreach (var line in workerLines)
        {
            var project = Get(line, "project");
            var projectId = Int(Get(line, "projectId")) ?? Int(Get(project, "id"));
            bool? enabled = Bool(Get(project, "enabled"));
            if (enabled is null && projectId is { } pid)
            {
                if (!projectCache.TryGetValue(pid, out project))
                {
                    sourceCalls.Add($"GET api/projects/{pid}");
                    try { project = await client.GetJsonAsync($"api/projects/{pid}", companyId, ct); projectCache[pid] = project; }
                    catch { /* leave enabled unknown -> not flagged */ }
                }
                enabled = Bool(Get(project, "enabled"));
            }
            if (enabled == false)
                disabledProjects.Add(new { projectId, projectCode = Str(Get(project, "code")), lineId = Int(Get(line, "id")) });
        }
        if (disabledProjects.Count > 0)
            Err("disabled-project", "One or more worker lines reference a disabled project.", disabledProjects);

        // 7. overtime / non-regular earning code rule (only meaningful when overtime rules are OFF)
        if (!overtimeRulesEnabled)
        {
            var badEarning = workerLines.Where(l =>
            {
                var earningCodeId = Int(Get(l, "earningCodeId"));
                if (earningCodeId is null || earningCodeId == regularEarningCodeId) return false;
                var ot = Num(Get(l, "overtimeHours")) ?? 0;
                var dt = Num(Get(l, "doubleTimeHours")) ?? 0;
                var tt = Num(Get(l, "tripleTimeHours")) ?? 0;
                if (ot == 0 && dt == 0 && tt == 0) return false;
                var ec = Get(l, "earningCode");
                var isProductive = Bool(Get(ec, "isProductive")) ?? true;
                var useInTimeOff = Bool(Get(ec, "useInTimeOff")) ?? false;
                return !isProductive && useInTimeOff;
            }).Select(l => new { lineId = Int(Get(l, "id")), earningCodeId = Int(Get(l, "earningCodeId")) }).ToList();
            if (badEarning.Count > 0)
                Err("invalid-overtime-earning-code",
                    "Overtime rules are disabled and one or more lines have overtime/double-time/triple-time hours against a non-regular, non-productive, time-off earning code.",
                    badEarning);
        }

        // 8. current status must be Processed (approval-specific)
        if (!string.Equals(currentStatus, "Processed", StringComparison.OrdinalIgnoreCase))
            Err("invalid-status-transition", $"Only timesheets in Processed status can be set to Approved (current status: {currentStatus ?? "unknown"}).");

        // 9. empty timesheet — two independent checks from the real service.
        // NOTE: the API's own hasHoursLine/hasExpensesLine flags were verified (live) to NOT
        // reliably reflect "workerlines/expenseLines array is non-empty" (seen false on a
        // timesheet with a populated workerlines array) — IsTimesheetEmptyAsync in SIS-APS is
        // literally "any worker/expense line row exists", so check the arrays directly instead.
        if (workerLines.Count == 0 && expenseLines.Count == 0)
        {
            Err("empty-timesheet", "This timesheet cannot be approved because it does not contain any lines.");
        }
        else
        {
            var allZeroHours = workerLines.Count == 0 || workerLines.All(l => LineTotalHours(l, overtimeRulesEnabled) == 0);
            var totalExpense = expenseLines.Sum(l => Num(Get(l, "totalAmount")) ?? 0);
            if (allZeroHours && totalExpense == 0)
                Err("empty-timesheet", "This timesheet cannot be approved because it does not contain any lines.");
        }

        // 10. duplicate hourly costs — no public endpoint exposes this check (verified against
        // the full deployed swagger); never silently report it as passed.
        Warn("duplicate-cost-check-unavailable", "Duplicate hourly costs could not be verified — no public API exposes this check.");

        return Result(timesheetId, currentStatus, errors, warnings, sourceCalls);
    }

    private static Dictionary<string, object?> Result(int timesheetId, string? currentStatus, List<object> errors, List<object> warnings, List<string> sourceCalls) =>
        new()
        {
            ["timesheetId"] = timesheetId,
            ["currentStatus"] = currentStatus,
            ["canApprove"] = errors.Count == 0,
            ["validationErrors"] = errors,
            ["warnings"] = warnings,
            ["sourceCalls"] = sourceCalls,
        };

    /// <summary>
    /// Mirrors TimesheetWorkerLine.GetTotalHours(bool) in SIS.APS.Core — NOT the API's own
    /// `totalHours` field, which the mapper always computes with the flag hardcoded to true.
    /// </summary>
    private static decimal LineTotalHours(JsonElement line, bool overtimeRulesEnabled)
    {
        var regular = Num(Get(line, "regularHours")) ?? 0;
        var overtime = Num(Get(line, "overtimeHours")) ?? 0;
        var doubleT = Num(Get(line, "doubleTimeHours")) ?? 0;
        var tripleT = Num(Get(line, "tripleTimeHours")) ?? 0;
        var separated = regular + overtime + doubleT + tripleT;

        if (!overtimeRulesEnabled) return separated;

        var overridden = Bool(Get(line, "overtimeHoursOveridden")) ?? false;
        var worked = Num(Get(line, "workedHours")) ?? 0;
        return overridden || worked == 0 ? separated : worked;
    }

    private static List<JsonElement> Arr(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.Array
            ? v.EnumerateArray().ToList() : [];

    private static JsonElement Get(JsonElement e, params string[] path)
    {
        var cur = e;
        foreach (var p in path)
        {
            if (cur.ValueKind != JsonValueKind.Object || !cur.TryGetProperty(p, out cur))
                return default;
        }
        return cur;
    }

    private static string? Str(JsonElement e) =>
        e.ValueKind == JsonValueKind.String ? e.GetString() : null;

    private static decimal? Num(JsonElement e) =>
        e.ValueKind == JsonValueKind.Number && e.TryGetDecimal(out var d) ? d : null;

    private static int? Int(JsonElement e) =>
        e.ValueKind == JsonValueKind.Number && e.TryGetInt32(out var n) ? n : null;

    private static bool? Bool(JsonElement e) =>
        e.ValueKind switch { JsonValueKind.True => true, JsonValueKind.False => false, _ => null };
}
