using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol;
using ModelContextProtocol.Server;
using SIS.Adle.Mcp.Server.Api;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>
/// Write operations on Advanced Labor timesheets: move one timesheet between statuses,
/// and run / track a batch job that moves many timesheets at once.
///
/// Typical approval flow: timesheets sit in <c>Processed</c>; a manager approves them,
/// moving them to <c>Approved</c>. Rejecting sends a timesheet back to <c>Rejected</c>.
/// Valid statuses: Draft, Rejected, Processed, Approved, Completed, StatementCreated, Void.
/// </summary>
[McpServerToolType]
public sealed class TimesheetApprovalTools(AdvancedLaborClient client)
{
    private static readonly string[] Statuses =
        ["Draft", "Rejected", "Processed", "Approved", "Completed", "StatementCreated", "Void"];

    // ---------------------------------------------------------------- single

    [McpServerTool(Name = "change_timesheet_status")]
    [Description("""
        Approve, reject, or otherwise change the status of ONE timesheet.
        PATCH api/timesheets/{timesheetId}/change-status  body {"status": "<status>"}.
        Use this for a single timesheet: e.g. status="Approved" to approve a Processed
        timesheet, status="Rejected" to reject it. For many timesheets at once use
        create_timesheet_batch_job instead.
        The API returns 204 No Content on success; this tool returns { ok:true, timesheetId, status }.
        Valid status values: Draft, Rejected, Processed, Approved, Completed, StatementCreated, Void.
        """)]
    public async Task<object> ChangeTimesheetStatus(
        [Description("The timesheet id (a.k.a. timesheet number) to change.")] int timesheetId,
        [Description("New status. Commonly 'Approved' or 'Rejected'.")] string status,
        [Description("Company id for the x-company header. Omit to use the server default.")] int? companyId = null,
        CancellationToken ct = default)
    {
        var norm = NormalizeStatus(status);
        if (norm is null)
            return new { error = $"Invalid status '{status}'. Use one of: {string.Join(", ", Statuses)}." };
        if (timesheetId <= 0)
            return new { error = "timesheetId must be a positive integer." };

        var (httpStatus, body) = await client.SendAsync(
            HttpMethod.Patch, $"api/timesheets/{timesheetId}/change-status",
            new { status = norm }, companyId, ct);

        return new
        {
            ok = true,
            timesheetId,
            status = norm,
            httpStatus,
            note = httpStatus == 204 ? "Status changed (204 No Content)." : "Status changed.",
            responseBody = string.IsNullOrWhiteSpace(body) ? null : body,
        };
    }

    // ---------------------------------------------------------------- batch: create

    [McpServerTool(Name = "create_timesheet_batch_job")]
    [Description("""
        Queue a BATCH job that changes the status of MANY timesheets in one call — e.g. approve
        a list of Processed timesheets. POST api/timesheets/batchjobs
        body {"currentStatus": "<current>", "timesheetIds": [ ... ]}.
        'currentStatus' is the status the timesheets are in NOW (e.g. "Processed"); the batch
        handler advances them to the next status (Processed -> Approved). The job runs
        asynchronously: this returns immediately with a jobId and status "Queued".
        Then poll it with wait_timesheet_batch_job (recommended) or get_timesheet_batch_job
        to find out when it finished and how many timesheets were updated.
        """)]
    public async Task<object> CreateTimesheetBatchJob(
        [Description("Status the timesheets are currently in, e.g. 'Processed'. The batch advances them from here.")] string currentStatus,
        [Description("Timesheet ids to include in the batch, e.g. [33433, 33435].")] int[] timesheetIds,
        [Description("Run recalculation as part of the batch. Usually false.")] bool doCalculation = false,
        [Description("Set true if the batch also covers expense lines.")] bool isExpenseEnabled = false,
        [Description("Company id for the x-company header. Omit to use the server default.")] int? companyId = null,
        CancellationToken ct = default)
    {
        var norm = NormalizeStatus(currentStatus);
        if (norm is null)
            return new { error = $"Invalid currentStatus '{currentStatus}'. Use one of: {string.Join(", ", Statuses)}." };
        if (timesheetIds is null or { Length: 0 })
            return new { error = "timesheetIds must contain at least one id." };

        var (_, body) = await client.SendAsync(
            HttpMethod.Post, "api/timesheets/batchjobs",
            new { currentStatus = norm, timesheetIds, doCalculation, isExpenseEnabled }, companyId, ct);

        var job = ParseJob(body);
        job["requestedTimesheetCount"] = timesheetIds.Length;
        job["nextStep"] = $"Poll wait_timesheet_batch_job with jobId={job["jobId"]}.";
        return job;
    }

    // ---------------------------------------------------------------- batch: get once

    [McpServerTool(Name = "get_timesheet_batch_job")]
    [Description("""
        Get the current state of a timesheet batch job (single check, no waiting).
        GET api/timesheets/batchjobs/{jobId}.
        status is one of: Queued, Running, Completed, Failed, CompletedWithErrors.
        When finished, 'infoMessage' summarises the result (e.g. "2 of 2 timesheets were
        updated to Approved status.") and affectedSuccessCount / affectedFailedCount give
        the counts. Use wait_timesheet_batch_job to block until it finishes.
        """)]
    public async Task<object> GetTimesheetBatchJob(
        [Description("The batch job id returned by create_timesheet_batch_job.")] int jobId,
        [Description("Company id for the x-company header. Omit to use the server default.")] int? companyId = null,
        CancellationToken ct = default)
    {
        var root = await client.GetJsonAsync($"api/timesheets/batchjobs/{jobId}", companyId, ct);
        return ParseJob(root);
    }

    // ---------------------------------------------------------------- batch: wait / poll loop

    [McpServerTool(Name = "wait_timesheet_batch_job")]
    [Description("""
        Poll a timesheet batch job until it finishes (or a timeout), then return the final
        result. Repeatedly calls GET api/timesheets/batchjobs/{jobId} every pollIntervalSeconds
        until status is Completed / Failed / CompletedWithErrors or maxWaitSeconds elapses.
        Returns the final job with 'infoMessage', 'progressText' (e.g. "processed 2 of 2"),
        affectedSuccessCount / affectedFailedCount, pollCount and timedOut.
        Call this right after create_timesheet_batch_job to report the outcome to the user.
        """)]
    public async Task<object> WaitTimesheetBatchJob(
        [Description("The batch job id to wait on.")] int jobId,
        [Description("Max seconds to keep polling before giving up (default 60, max 600).")] int maxWaitSeconds = 60,
        [Description("Seconds between polls (default 3, min 1).")] int pollIntervalSeconds = 3,
        [Description("Company id for the x-company header. Omit to use the server default.")] int? companyId = null,
        IProgress<ProgressNotificationValue>? progress = null,
        CancellationToken ct = default)
    {
        maxWaitSeconds = Math.Clamp(maxWaitSeconds, 1, 600);
        pollIntervalSeconds = Math.Clamp(pollIntervalSeconds, 1, 60);

        var deadline = DateTimeOffset.UtcNow.AddSeconds(maxWaitSeconds);
        var terminal = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "Completed", "Failed", "CompletedWithErrors" };

        Dictionary<string, object?> job = new();
        var polls = 0;
        while (true)
        {
            polls++;
            var root = await client.GetJsonAsync($"api/timesheets/batchjobs/{jobId}", companyId, ct);
            job = ParseJob(root);
            var status = job.TryGetValue("status", out var s) ? s?.ToString() ?? "" : "";

            progress?.Report(new ProgressNotificationValue
            {
                Progress = polls,
                Message = $"batch job {jobId}: {status} ({job.GetValueOrDefault("progressText")})",
            });

            if (terminal.Contains(status))
            {
                job["pollCount"] = polls;
                job["timedOut"] = false;
                return job;
            }

            if (DateTimeOffset.UtcNow >= deadline)
            {
                job["pollCount"] = polls;
                job["timedOut"] = true;
                job["note"] = $"Still '{status}' after {maxWaitSeconds}s. Call get_timesheet_batch_job later.";
                return job;
            }

            await Task.Delay(TimeSpan.FromSeconds(pollIntervalSeconds), ct);
        }
    }

    // ---------------------------------------------------------------- helpers

    private static string? NormalizeStatus(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        return Statuses.FirstOrDefault(s => s.Equals(value.Trim(), StringComparison.OrdinalIgnoreCase));
    }

    private static Dictionary<string, object?> ParseJob(string body)
    {
        if (string.IsNullOrWhiteSpace(body)) return new() { ["raw"] = null };
        using var doc = JsonDocument.Parse(body);
        return ParseJob(doc.RootElement);
    }

    private static Dictionary<string, object?> ParseJob(JsonElement r)
    {
        int?[] affected = r.TryGetProperty("affectedTimesheetIds", out var at) && at.ValueKind == JsonValueKind.Array
            ? at.EnumerateArray().Select(x => x.TryGetInt32(out var v) ? (int?)v : null).ToArray()
            : [];
        var success = Int(r, "affectedSuccessCount");
        var failed = Int(r, "affectedFailedCount");
        var total = Int(r, "affectedCount") ?? affected.Length;
        var info = Str(r, "infoMessage");

        string progressText = info
            ?? (total > 0 ? $"processed {(success ?? 0) + (failed ?? 0)} of {total}" : "no progress reported yet");

        return new Dictionary<string, object?>
        {
            ["jobId"] = Int(r, "id"),
            ["status"] = EnumStr(r, "status"),
            ["type"] = Str(r, "type"),
            ["infoMessage"] = info,
            ["errorMessage"] = Str(r, "errorMessage"),
            ["progressText"] = progressText,
            ["affectedSuccessCount"] = success,
            ["affectedFailedCount"] = failed,
            ["affectedCount"] = total,
            ["affectedTimesheetIds"] = affected,
            ["queuedAt"] = Str(r, "queuedAt"),
            ["startedAt"] = Str(r, "startedAt"),
            ["endedAt"] = Str(r, "endedAt"),
            ["requestedBy"] = Int(r, "requestedBy"),
        };
    }

    private static string? Str(JsonElement e, string p) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(p, out var v)
            && v.ValueKind is not (JsonValueKind.Null or JsonValueKind.Undefined)
            ? (v.ValueKind == JsonValueKind.String ? v.GetString() : v.ToString())
            : null;

    private static int? Int(JsonElement e, string p) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(p, out var v) && v.TryGetInt32(out var n) ? n : null;

    private static string? EnumStr(JsonElement e, string p)
    {
        if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(p, out var v)) return null;
        return v.ValueKind switch
        {
            JsonValueKind.String => v.GetString(),
            JsonValueKind.Number => v.ToString(),
            JsonValueKind.Object => v.TryGetProperty("description", out var d) && d.ValueKind == JsonValueKind.String ? d.GetString()
                                  : v.TryGetProperty("id", out var i) ? i.ToString() : null,
            _ => null,
        };
    }
}
