using System.ComponentModel;
using System.Security.Claims;
using Microsoft.IdentityModel.JsonWebTokens;
using ModelContextProtocol.Server;
using SIS.Adle.Mcp.Server.Auth;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>
/// Minimal diagnostic tool: echoes the caller's identity.
///   - normal path: from the validated bearer token on the request.
///   - dev path (Mcp:DevAutoLogin): from a token the server fetches itself via
///     OAuth2 password grant, so Copilot Studio can connect with auth = None.
/// </summary>
[McpServerToolType]
public sealed class UserTools
{
    private readonly IHttpContextAccessor _http;
    private readonly IDevTokenService _devToken;

    public UserTools(IHttpContextAccessor http, IDevTokenService devToken)
    {
        _http = http;
        _devToken = devToken;
    }

    [McpServerTool(Name = "get_user_details")]
    [Description("Returns the signed-in user's details (name, ids, email, token metadata and all claims). Use this to verify that login succeeded.")]
    public async Task<object> GetUserDetails(CancellationToken ct)
    {
        var user = _http.HttpContext?.User;

        if (user?.Identity is { IsAuthenticated: true })
            return Describe("request-bearer-token", user.Claims, user.Identity.AuthenticationType);

        if (_devToken.Enabled)
        {
            var tok = await _devToken.GetAsync(ct);
            return Describe("dev-ropc-token", tok.Jwt.Claims, "DevRopc",
                extra: new { tokenExpiresOn = tok.ExpiresOn });
        }

        return new
        {
            authenticated = false,
            message = "No bearer token on the request and Mcp:DevAutoLogin is false.",
        };
    }

    private static object Describe(string source, IEnumerable<Claim> claimsSource, string? authType, object? extra = null)
    {
        var claims = claimsSource.ToList();

        string? First(params string[] types) =>
            types.Select(t => claims.FirstOrDefault(c => c.Type == t)?.Value)
                 .FirstOrDefault(v => !string.IsNullOrEmpty(v));

        var emails = claims.Where(c => c.Type == "emails").Select(c => c.Value)
            .Concat(new[] { First(ClaimTypes.Email, "email", "preferred_username") })
            .Where(v => !string.IsNullOrEmpty(v))
            .Distinct()
            .ToArray();

        return new
        {
            authenticated = true,
            source,
            name = First("name", ClaimTypes.Name, "given_name"),
            objectId = First("oid", "http://schemas.microsoft.com/identity/claims/objectidentifier"),
            subject = First("sub", ClaimTypes.NameIdentifier),
            emails,
            tenantId = First("tid", "http://schemas.microsoft.com/identity/claims/tenantid"),
            identityProvider = First("idp"),
            userFlow = First("tfp", "acr"),
            scope = First("scp", "http://schemas.microsoft.com/identity/claims/scope"),
            issuer = First("iss"),
            audience = First("aud"),
            authenticationType = authType,
            extra,
            claims = claims.GroupBy(c => c.Type)
                           .ToDictionary(g => g.Key, g => g.Select(c => c.Value).ToArray()),
        };
    }
}
