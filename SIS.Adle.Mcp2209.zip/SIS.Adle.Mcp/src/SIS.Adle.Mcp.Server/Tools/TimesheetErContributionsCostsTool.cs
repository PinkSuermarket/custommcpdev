using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Server;
using SIS.Adle.Mcp.Server.Api;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>
/// get_timesheet_ercontributions_costs — GET api/timesheets/costs/ercontributions.
/// Employer benefit / cash-in-lieu override cost lines (ERBenefitsInquiryOutput).
/// </summary>
[McpServerToolType]
public sealed class TimesheetErContributionsCostsTool(AdvancedLaborClient client)
{
    [McpServerTool(Name = "get_timesheet_ercontributions_costs")]
    [Description("Employer-contribution (ER benefit / cash-in-lieu override) cost lines from the Advanced Labor " +
                "Timesheet Cost Inquiry (GET api/timesheets/costs/ercontributions). Returns { totalCount, count, rows }.")]
    public async Task<object> Get(
        int? companyId = null, bool includeRaw = false,
        [Description("Inclusive start date, yyyy-MM-dd.")] string? startDate = null,
        [Description("Inclusive end date, yyyy-MM-dd.")] string? endDate = null,
        [Description("Single worker id.")] int? workerId = null,
        [Description("Comma-separated worker ids.")] string? workerIds = null,
        [Description("Comma-separated project ids.")] string? projectIds = null,
        [Description("Single timesheet id.")] int? timesheetId = null,
        [Description("Comma-separated timesheet ids.")] string? timesheetIds = null,
        [Description("Timesheet status: Draft|Rejected|Processed|Approved|Completed|StatementCreated|Void.")] string? timesheetStatus = null,
        [Description("Comma-separated status names.")] string? statusValues = null,
        [Description("Exception criteria id.")] int? exceptionCriteriaId = null,
        [Description("true = only rows with an exception criteria, false = only without.")] bool? hasExceptionCriteria = null,
        [Description("Include all rows regardless of default filtering.")] bool? showAll = null,
        [Description("Free-text search term.")] string? searchTerm = null,
        [Description("Zero-based page index.")] int pageIndex = 0,
        [Description("Page size 1-300 (default 25).")] int pageSize = 25,
        [Description("Property name to sort by.")] string? sortProperty = null,
        [Description("Asc | Desc.")] string? sortDirection = null,
        CancellationToken ct = default)
    {
        if (pageSize is < 1 or > 300)
            return new { error = "pageSize must be between 1 and 300." };

        var query = new TimesheetCostQuery
        {
            StartDate = DateOnly.TryParse(startDate, out var s) ? s : null,
            EndDate = DateOnly.TryParse(endDate, out var e) ? e : null,
            WorkerId = workerId,
            WorkerIds = workerIds,
            ProjectIds = projectIds,
            TimesheetId = timesheetId,
            TimesheetIds = timesheetIds,
            TimesheetStatus = timesheetStatus,
            StatusValues = statusValues,
            ExceptionCriteriaId = exceptionCriteriaId,
            HasExceptionCriteria = hasExceptionCriteria,
            ShowAll = showAll,
            SearchTerm = searchTerm,
            PageIndex = pageIndex,
            PageSize = pageSize,
            SortProperty = sortProperty,
            SortDirection = sortDirection,
        };

        var root = await client.GetTimesheetCostsAsync("ercontributions", query, companyId, ct);
        var data = CostJson.Data(root);
        var totalCount = CostJson.TotalCount(root);

        if (includeRaw)
            return new { totalCount, count = data.ValueKind == JsonValueKind.Array ? data.GetArrayLength() : 0, rows = data };

        var rows = new List<object>();
        if (data.ValueKind == JsonValueKind.Array)
            foreach (var r in data.EnumerateArray())
                rows.Add(new
                {
                    worker = CostJson.Str(r, "worker"),
                    personnelNumber = CostJson.Str(r, "personnelNumber"),
                    companyCode = CostJson.Str(r, "companyCode"),
                    date = CostJson.Str(r, "date"),
                    projectCode = CostJson.Str(r, "projectCode"),
                    projectName = CostJson.Str(r, "projectName"),
                    jobclassCode = CostJson.Str(r, "jobclassCode"),
                    jobclassName = CostJson.Str(r, "jobclassName"),
                    erBenefitCode = CostJson.Str(r, "erBenefitCode"),
                    paygroupCode = CostJson.Str(r, "paygroupCode"),
                    paygroupName = CostJson.Str(r, "paygroupName"),
                    totalHours = CostJson.Num(r, "totalHours"),
                    cashInLieuRate = CostJson.Num(r, "cashInLieuRate"),
                    totalAmount = CostJson.Num(r, "totalAmount"),
                    editedTotalAmount = CostJson.Num(r, "editedTotalAmount"),
                    source = CostJson.Enum(r, "source"),
                    actualSource = CostJson.Str(r, "actualSource"),
                    timesheetStatus = CostJson.Enum(r, "timesheetStatus"),
                    exceptionCriteriaCode = CostJson.Str(r, "exceptionCriteriaCode"),
                    exceptionEditedBy = CostJson.Str(r, "exceptionEditedBy"),
                    timesheetId = CostJson.Num(r, "timesheetId"),
                    timesheetCashInLieuOverrideCostId = CostJson.Num(r, "timesheetCashInLieuOverrideCostId"),
                });

        return new { totalCount, count = rows.Count, rows };
    }
}
