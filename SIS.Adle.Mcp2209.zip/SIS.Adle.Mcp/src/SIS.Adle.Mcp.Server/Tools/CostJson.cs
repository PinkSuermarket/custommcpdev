using System.Text.Json;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>Shared JSON readers for the Timesheet Cost Inquiry tools (API returns camelCase).</summary>
internal static class CostJson
{
    public static JsonElement Data(JsonElement root) =>
        root.ValueKind == JsonValueKind.Object && root.TryGetProperty("data", out var d) && d.ValueKind == JsonValueKind.Array
            ? d : default;

    public static int? TotalCount(JsonElement root) =>
        root.ValueKind == JsonValueKind.Object && root.TryGetProperty("totalCount", out var tc) && tc.TryGetInt32(out var n)
            ? n : null;

    public static string? Str(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v) && v.ValueKind is not (JsonValueKind.Null or JsonValueKind.Undefined)
            ? (v.ValueKind == JsonValueKind.String ? v.GetString() : v.ToString())
            : null;

    public static decimal? Num(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.Number && v.TryGetDecimal(out var d)
            ? d : null;

    // EnumItemOutput serialises as { "id": "..", "description": ".." }; sometimes a plain string.
    public static string? Enum(JsonElement e, string prop)
    {
        if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(prop, out var v)) return null;
        return v.ValueKind switch
        {
            JsonValueKind.String => v.GetString(),
            JsonValueKind.Object => v.TryGetProperty("description", out var desc) && desc.ValueKind == JsonValueKind.String ? desc.GetString()
                                  : v.TryGetProperty("id", out var id) ? id.ToString() : null,
            _ => null,
        };
    }
}
