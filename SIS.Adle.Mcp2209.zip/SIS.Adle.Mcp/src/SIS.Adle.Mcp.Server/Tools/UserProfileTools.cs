using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Server;
using SIS.Adle.Mcp.Server.Api;
using SIS.Adle.Mcp.Server.Auth;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>
/// The signed-in user's Advanced Labor profile — companies and roles — from
/// GET api/users/{id}, where {id} is always the CALLER's own id (the token's
/// extension_UserId claim), never a parameter the model supplies.
///
/// Separate from the existing get_user_details tool (Tools/UserTools.cs), which is left
/// untouched — that one echoes raw token claims; this one calls the real Advanced Labor
/// user profile API and remembers the user's companies for other tools to default to.
/// </summary>
[McpServerToolType]
public sealed class UserProfileTools(AdvancedLaborClient client, CurrentUserResolver currentUser, UserContextCache companyCache)
{
    [McpServerTool(Name = "get_al_user_profile")]
    [Description("""
        The signed-in user's Advanced Labor profile: name, email, the companies they're
        authorized for, and their roles. Takes NO id — it always resolves to whoever is
        currently signed in (from their access token), so never ask the user for their own
        id or pass one in. Call this once near the start of a session to learn which
        companies the user can act on; other tools will then default to one of those
        companies automatically if a company isn't specified.
        """)]
    public async Task<object> GetUserProfile(CancellationToken ct)
    {
        var userId = await currentUser.GetUserIdAsync(ct);
        if (userId is null)
            return new { error = "Could not resolve the signed-in user's id (extension_UserId claim) from the current token." };

        var root = await client.GetJsonAsync($"api/users/{userId}", null, ct);
        if (root.ValueKind != JsonValueKind.Object)
            return new { error = $"User {userId} was not found." };

        var companyIds = Arr(root, "companyIds").Select(v => v.TryGetInt32(out var n) ? n : (int?)null)
            .Where(n => n is not null).Select(n => n!.Value).ToArray();
        if (companyIds.Length > 0)
            companyCache.Remember(userId.Value, companyIds);

        var companies = Arr(root, "companies").Select(c => new
        {
            id = Int(c, "id"),
            code = Str(c, "code"),
            companyName = Str(c, "companyName"),
        });

        var roles = Arr(root, "roles").Select(r => new
        {
            id = Int(r, "id"),
            name = Str(r, "name"),
        });

        return new
        {
            id = Int(root, "id"),
            firstName = Str(root, "firstName"),
            lastName = Str(root, "lastName"),
            email = Str(root, "email"),
            ssoLoginOnly = Bool(root, "ssoLoginOnly"),
            companyIds,
            companies,
            roles,
        };
    }

    private static List<JsonElement> Arr(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.Array
            ? v.EnumerateArray().ToList() : [];

    private static string? Str(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    private static int? Int(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v) && v.TryGetInt32(out var n) ? n : null;

    private static bool? Bool(JsonElement e, string prop) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(prop, out var v)
            ? v.ValueKind switch { JsonValueKind.True => true, JsonValueKind.False => false, _ => null }
            : null;
}
