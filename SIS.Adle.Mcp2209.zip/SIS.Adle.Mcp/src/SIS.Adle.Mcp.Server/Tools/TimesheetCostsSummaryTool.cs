using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Server;
using SIS.Adle.Mcp.Server.Api;

namespace SIS.Adle.Mcp.Server.Tools;

/// <summary>
/// get_timesheet_costs_summary — GET api/timesheets/costs/summary.
/// Hours &amp; cost totals bucketed by Regular / Overtime / DoubleTime / TripleTime / Others / TimeOff.
/// No paging; the same filters as the list sections still apply.
/// </summary>
[McpServerToolType]
public sealed class TimesheetCostsSummaryTool(AdvancedLaborClient client)
{
    [McpServerTool(Name = "get_timesheet_costs_summary")]
    [Description("Timesheet cost summary from the Advanced Labor Cost Inquiry (GET api/timesheets/costs/summary). " +
                "Returns hours and cost totals per bucket (regular, overtime, doubleTime, tripleTime, others, timeOff) " +
                "plus a computed grand total. No paging. Filters optional.")]
    public async Task<object> Get(
        int? companyId = null, bool includeRaw = false,
        [Description("Inclusive start date, yyyy-MM-dd.")] string? startDate = null,
        [Description("Inclusive end date, yyyy-MM-dd.")] string? endDate = null,
        [Description("Single worker id.")] int? workerId = null,
        [Description("Comma-separated worker ids.")] string? workerIds = null,
        [Description("Comma-separated project ids.")] string? projectIds = null,
        [Description("Single timesheet id.")] int? timesheetId = null,
        [Description("Comma-separated timesheet ids.")] string? timesheetIds = null,
        [Description("Timesheet status: Draft|Rejected|Processed|Approved|Completed|StatementCreated|Void.")] string? timesheetStatus = null,
        [Description("Comma-separated status names.")] string? statusValues = null,
        [Description("Include all rows regardless of default filtering.")] bool? showAll = null,
        [Description("Free-text search term.")] string? searchTerm = null,
        CancellationToken ct = default)
    {
        var query = new TimesheetCostQuery
        {
            StartDate = DateOnly.TryParse(startDate, out var s) ? s : null,
            EndDate = DateOnly.TryParse(endDate, out var e) ? e : null,
            WorkerId = workerId,
            WorkerIds = workerIds,
            ProjectIds = projectIds,
            TimesheetId = timesheetId,
            TimesheetIds = timesheetIds,
            TimesheetStatus = timesheetStatus,
            StatusValues = statusValues,
            ShowAll = showAll,
            SearchTerm = searchTerm,
            // no PageIndex / PageSize for summary
        };

        var root = await client.GetTimesheetCostsAsync("summary", query, companyId, ct);

        if (includeRaw || root.ValueKind != JsonValueKind.Object)
            return new { raw = root };

        (decimal hours, decimal cost) Bucket(string name)
        {
            if (!root.TryGetProperty(name, out var b) || b.ValueKind != JsonValueKind.Object) return (0, 0);
            return (CostJson.Num(b, "hours") ?? 0, CostJson.Num(b, "cost") ?? 0);
        }

        var names = new[] { "regular", "overtime", "doubleTime", "tripleTime", "others", "timeOff" };
        var buckets = names.ToDictionary(n => n, n => { var (h, c) = Bucket(n); return new { hours = h, cost = c }; });

        return new
        {
            regular = buckets["regular"],
            overtime = buckets["overtime"],
            doubleTime = buckets["doubleTime"],
            tripleTime = buckets["tripleTime"],
            others = buckets["others"],
            timeOff = buckets["timeOff"],
            total = new
            {
                hours = buckets.Values.Sum(b => b.hours),
                cost = buckets.Values.Sum(b => b.cost),
            },
        };
    }
}
