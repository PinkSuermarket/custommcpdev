using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Identity.Web;
using ModelContextProtocol.AspNetCore.Authentication;
using ModelContextProtocol.Authentication;

namespace SIS.Adle.Mcp.Server.Auth;

/// <summary>
/// Wires MCP server authentication from the single <c>Mcp:DevAutoLogin</c> flag.
///
/// <para><b>DevAutoLogin = true</b> — dev mode auto login. No JWT validation is wired;
/// <c>/mcp</c> is left open (see Program.cs) and the server signs itself in via OAuth2
/// password grant (<see cref="DevTokenService"/>). Local development only.</para>
///
/// <para><b>DevAutoLogin = false</b> — the server is an OAuth2 <b>resource server</b>,
/// validated with <b>Microsoft.Identity.Web</b>'s <c>AddMicrosoftIdentityWebApi</c>
/// against Azure AD B2C (<see cref="AzureAdB2COptions"/>) — moved here after being proven
/// in the standalone SIS.Adle.AuthTest project (which also caught two config bugs: the
/// real Microsoft.Identity.Web key is "SignUpSignInPolicyId", and the token audience for
/// this API is the resource app id, not the client/SPA app id originally configured here).
/// It publishes an RFC 9728 protected-resource metadata document so the client can
/// discover the authorization server and run auth-code + PKCE.</para>
/// </summary>
public static class McpAuthenticationExtensions
{
    public static WebApplicationBuilder AddMcpAuthentication(this WebApplicationBuilder builder)
    {
        var options = new McpServerOptions();
        builder.Configuration.GetSection(McpServerOptions.SectionName).Bind(options);
        builder.Services.Configure<McpServerOptions>(
            builder.Configuration.GetSection(McpServerOptions.SectionName));

        if (options.DevAutoLogin)
        {
            // Dev auto login: nothing to validate — the server mints its own token.
            builder.Services.AddAuthentication();
            builder.Services.AddAuthorization();
            return builder;
        }

        var b2c = options.AzureAdB2C;
        if (!b2c.IsComplete)
            throw new InvalidOperationException(
                "Mcp:AzureAdB2C (Instance, Domain, ClientId, SignUpSignInPolicyId) is required when Mcp:DevAutoLogin is false.");

        if (builder.Environment.IsDevelopment())
            Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII = true; // verbose IDX messages, dev only

        // AddMicrosoftIdentityWebApi returns a narrower builder type that can't chain
        // .AddMcp() — both register into the same underlying AuthenticationBuilder
        // (confirmed in SIS.Adle.AuthTest), so call them separately on the same reference.
        var authBuilder = builder.Services.AddAuthentication(o =>
        {
            o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            // Challenges go through the MCP handler so 401s carry the
            // WWW-Authenticate: Bearer resource_metadata="..." hint.
            o.DefaultChallengeScheme = McpAuthenticationDefaults.AuthenticationScheme;
        });

        authBuilder.AddMicrosoftIdentityWebApi(
            builder.Configuration.GetSection($"{McpServerOptions.SectionName}:AzureAdB2C"),
            subscribeToJwtBearerMiddlewareDiagnosticsEvents: builder.Environment.IsDevelopment());

        authBuilder.AddMcp(o =>
        {
            o.ResourceMetadata = new ProtectedResourceMetadata
            {
                Resource = options.ServerUrl,
                // Point at THIS server's origin; OAuthMetadataEndpoints relays B2C's
                // metadata there (B2C has no RFC 8414 endpoint of its own).
                AuthorizationServers = { options.ServerUrl.TrimEnd('/') },
            };
            foreach (var scope in b2c.ScopesSupported)
                o.ResourceMetadata.ScopesSupported.Add(scope);
        });

        builder.Services.AddAuthorization(o =>
        {
            o.FallbackPolicy = o.DefaultPolicy; // every endpoint requires auth unless it opts out
        });

        return builder;
    }
}
