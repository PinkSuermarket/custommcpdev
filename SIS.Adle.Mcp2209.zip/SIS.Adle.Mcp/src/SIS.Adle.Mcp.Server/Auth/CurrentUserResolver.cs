using System.Security.Claims;

namespace SIS.Adle.Mcp.Server.Auth;

/// <summary>
/// Resolves the signed-in caller's Advanced Labor user id (the "extension_UserId" claim)
/// using the same dual-path identity lookup as UserTools.GetUserDetails — the validated
/// request principal first, else the dev ROPC token's claims. Read-only reuse of that
/// pattern; UserTools.cs itself is not touched.
/// </summary>
public sealed class CurrentUserResolver(IHttpContextAccessor http, IDevTokenService devToken)
{
    public async Task<int?> GetUserIdAsync(CancellationToken ct)
    {
        var claims = await GetClaimsAsync(ct);
        var raw = claims?.FirstOrDefault(c => c.Type == "extension_UserId")?.Value;
        return int.TryParse(raw, out var id) ? id : null;
    }

    public async Task<IReadOnlyList<Claim>?> GetClaimsAsync(CancellationToken ct)
    {
        var user = http.HttpContext?.User;
        if (user?.Identity is { IsAuthenticated: true })
            return user.Claims.ToList();

        if (devToken.Enabled)
            return (await devToken.GetAsync(ct)).Jwt.Claims.ToList();

        return null;
    }
}
