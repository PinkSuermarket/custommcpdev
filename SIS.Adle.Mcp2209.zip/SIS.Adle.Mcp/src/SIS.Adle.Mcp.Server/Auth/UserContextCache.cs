using System.Collections.Concurrent;

namespace SIS.Adle.Mcp.Server.Auth;

/// <summary>
/// "Remembers" the companies a user is authorized for, in memory, for the life of the
/// process — populated by get_al_user_profile (Tools/UserProfileTools.cs), consulted by
/// AdvancedLaborClient as a fallback source for the x-company header when a tool call
/// doesn't specify companyId and no static Mcp:AdvancedLaborApi:DefaultCompanyId is set.
/// Never overrides an explicit companyId argument.
/// </summary>
public sealed class UserContextCache
{
    private static readonly TimeSpan Ttl = TimeSpan.FromMinutes(30);

    private sealed record Entry(int[] CompanyIds, DateTimeOffset ExpiresAt);

    private readonly ConcurrentDictionary<int, Entry> _byUserId = new();

    public void Remember(int userId, IEnumerable<int> companyIds) =>
        _byUserId[userId] = new Entry(companyIds.ToArray(), DateTimeOffset.UtcNow.Add(Ttl));

    /// <summary>The first remembered company id for this user, or null if never cached / expired.</summary>
    public int? GetDefaultCompanyId(int userId)
    {
        if (_byUserId.TryGetValue(userId, out var e) && e.ExpiresAt > DateTimeOffset.UtcNow && e.CompanyIds.Length > 0)
            return e.CompanyIds[0];
        return null;
    }
}
