using System.Text.Json.Nodes;
using Microsoft.Extensions.Options;

namespace SIS.Adle.Mcp.Server.Auth;

/// <summary>
/// OAuth metadata shim for MCP clients (Copilot).
///
/// Azure AD B2C serves OpenID discovery at <c>{authority}/v2.0/.well-known/openid-configuration</c>
/// but does NOT serve RFC 8414 <c>/.well-known/oauth-authorization-server</c>, and has no
/// dynamic client registration. Clients that probe RFC 8414 at the advertised authorization
/// server fail with "Could not discover authorization server metadata".
///
/// This relays B2C's metadata under THIS server's origin (so it is discoverable at the URL
/// the protected-resource document points at) and adds a stub <c>registration_endpoint</c>
/// that hands back the pre-registered public client id. Actual login/token exchange still
/// happens at B2C (authorization_endpoint / token_endpoint are unchanged).
///
/// Only active when <c>Mcp:DevAutoLogin</c> is false.
/// </summary>
public static class OAuthMetadataEndpoints
{
    public static void MapOAuthMetadataShim(this WebApplication app)
    {
        var opt = app.Services.GetRequiredService<IOptions<McpServerOptions>>().Value;
        if (opt.DevAutoLogin) return;

        var b2c = opt.AzureAdB2C;
        var httpFactory = app.Services.GetRequiredService<IHttpClientFactory>();
        var selfIssuer = opt.ServerUrl.TrimEnd('/');
        JsonObject? cached = null;

        async Task<JsonObject> BuildDocAsync(CancellationToken ct)
        {
            if (cached is not null) return (JsonObject)cached.DeepClone()!;

            using var http = httpFactory.CreateClient();
            var raw = await http.GetStringAsync(b2c.MetadataAddress, ct);
            var doc = JsonNode.Parse(raw)!.AsObject();

            // Present this server as the issuer so clients that check issuer == fetch origin pass.
            doc["issuer"] = selfIssuer;
            doc["registration_endpoint"] = $"{selfIssuer}/register";
            // Steer clients to public-client + PKCE (matches the /register response).
            doc["token_endpoint_auth_methods_supported"] = new JsonArray("none");
            doc["code_challenge_methods_supported"] ??= new JsonArray("S256");
            doc["grant_types_supported"] ??= new JsonArray("authorization_code", "refresh_token");
            doc["response_types_supported"] ??= new JsonArray("code");
            if (doc["scopes_supported"] is null && b2c.ScopesSupported.Length > 0)
                doc["scopes_supported"] = new JsonArray(b2c.ScopesSupported.Select(s => (JsonNode)s!).ToArray());

            cached = doc;
            return (JsonObject)doc.DeepClone()!;
        }

        string[] metaPaths =
        [
            "/.well-known/oauth-authorization-server",
            "/.well-known/oauth-authorization-server/mcp",
            "/.well-known/openid-configuration",
            "/.well-known/openid-configuration/mcp",
        ];
        foreach (var path in metaPaths)
            app.MapGet(path, async (CancellationToken ct) =>
                    Results.Content((await BuildDocAsync(ct)).ToJsonString(), "application/json"))
                .AllowAnonymous();

        // B2C has no DCR — return the configured public client.
        app.MapPost("/register", (JsonObject? body) =>
        {
            var reg = new JsonObject
            {
                ["client_id"] = b2c.ClientId,
                ["token_endpoint_auth_method"] = "none",
                ["grant_types"] = new JsonArray("authorization_code", "refresh_token"),
                ["response_types"] = new JsonArray("code"),
            };
            if (body?["redirect_uris"] is JsonArray ru) reg["redirect_uris"] = ru.DeepClone();
            if (body?["client_name"] is { } cn) reg["client_name"] = cn.DeepClone();
            return Results.Json(reg, statusCode: StatusCodes.Status201Created);
        }).AllowAnonymous();
    }
}
