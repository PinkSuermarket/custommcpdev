using System.Text.Json;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.JsonWebTokens;
using SIS.Adle.Mcp.Server.Auth;

namespace SIS.Adle.Mcp.Server.Auth;

public sealed record DevAccessToken(string AccessToken, DateTimeOffset ExpiresOn, JsonWebToken Jwt);

public interface IDevTokenService
{
    bool Enabled { get; }

    /// <summary>Returns a cached dev bearer token, fetching a new one via ROPC when expired.</summary>
    Task<DevAccessToken> GetAsync(CancellationToken ct = default);
}

/// <summary>
/// DEV ONLY. OAuth2 password grant (ROPC) — same request shape as
/// <c>SIS.APS.Core.Common.Authentication.C365Field.C365FieldTokenService</c>.
/// Caches the token in memory until ~60s before expiry.
/// </summary>
public sealed class DevTokenService : IDevTokenService
{
    private readonly HttpClient _http;
    private readonly DevTokenOptions _opt;
    private readonly bool _devAutoLogin;
    private readonly ILogger<DevTokenService> _log;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private DevAccessToken? _cached;

    public DevTokenService(HttpClient http, IOptions<McpServerOptions> opt, ILogger<DevTokenService> log)
    {
        _http = http;
        _opt = opt.Value.DevToken;
        _devAutoLogin = opt.Value.DevAutoLogin;
        _log = log;
    }

    public bool Enabled => _devAutoLogin;

    public async Task<DevAccessToken> GetAsync(CancellationToken ct = default)
    {
        if (!_devAutoLogin)
            throw new InvalidOperationException("Mcp:DevAutoLogin is false.");

        // Pasted-token path — no network call.
        if (!string.IsNullOrWhiteSpace(_opt.StaticToken))
        {
            var jwt = new JsonWebToken(_opt.StaticToken.Trim());
            var exp = jwt.ValidTo != DateTime.MinValue ? new DateTimeOffset(jwt.ValidTo, TimeSpan.Zero) : DateTimeOffset.MaxValue;
            if (exp <= DateTimeOffset.UtcNow)
                _log.LogWarning("Mcp:DevToken:StaticToken is expired ({Exp:u}). Paste a fresh one.", exp);
            return new DevAccessToken(_opt.StaticToken.Trim(), exp, jwt);
        }

        if (_cached is { } c && c.ExpiresOn > DateTimeOffset.UtcNow.AddSeconds(60))
            return c;

        await _gate.WaitAsync(ct);
        try
        {
            if (_cached is { } c2 && c2.ExpiresOn > DateTimeOffset.UtcNow.AddSeconds(60))
                return c2;

            _cached = await FetchAsync(ct);
            return _cached;
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task<DevAccessToken> FetchAsync(CancellationToken ct)
    {
        foreach (var (k, v) in new[] { ("TokenUrl", _opt.TokenUrl), ("ClientId", _opt.ClientId), ("UserId", _opt.UserId), ("Password", _opt.Password) })
            if (string.IsNullOrWhiteSpace(v))
                throw new InvalidOperationException($"Mcp:DevToken:{k} is required when DevToken is enabled.");

        using var body = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["grant_type"] = "password",
            ["client_id"] = _opt.ClientId,
            ["scope"] = _opt.Scope,
            ["username"] = _opt.UserId,
            ["password"] = _opt.Password,
        });

        using var resp = await _http.PostAsync(_opt.TokenUrl, body, ct);
        var text = await resp.Content.ReadAsStringAsync(ct);

        if (!resp.IsSuccessStatusCode)
        {
            _log.LogError("Dev ROPC token request failed: {Status} {Body}", (int)resp.StatusCode, text);
            throw new HttpRequestException($"Dev ROPC token request failed: {(int)resp.StatusCode}. {Trim(text)}");
        }

        using var doc = JsonDocument.Parse(text);
        var root = doc.RootElement;
        var accessToken =
            (root.TryGetProperty("access_token", out var at) ? at.GetString() : null)
            ?? (root.TryGetProperty("id_token", out var it) ? it.GetString() : null)
            ?? throw new InvalidOperationException($"No access_token/id_token in ROPC response. {Trim(text)}");

        var jwt = new JsonWebToken(accessToken);
        var expiresOn = jwt.ValidTo != DateTime.MinValue ? new DateTimeOffset(jwt.ValidTo, TimeSpan.Zero)
            : DateTimeOffset.UtcNow.AddMinutes(root.TryGetProperty("expires_in", out var ei) && ei.TryGetInt32(out var s) ? s / 60.0 : 55);

        _log.LogInformation("Dev ROPC token acquired for {User}, expires {Exp:u}", _opt.UserId, expiresOn);
        return new DevAccessToken(accessToken, expiresOn, jwt);
    }

    private static string Trim(string s) => s.Length > 500 ? s[..500] + "…" : s;
}
