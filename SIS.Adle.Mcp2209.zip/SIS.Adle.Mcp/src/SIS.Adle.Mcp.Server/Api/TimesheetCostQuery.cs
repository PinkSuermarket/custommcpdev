using System.Globalization;

namespace SIS.Adle.Mcp.Server.Api;

/// <summary>
/// Bindable subset of the API's <c>TimesheetCostInquiryListInput</c> (+ its bases
/// TimesheetInquiryListInput / SearchableListInput / ListInput). Every <c>[BindNever]</c>
/// member of the server DTO is deliberately omitted.
/// </summary>
public sealed class TimesheetCostQuery
{
    // dates
    public DateOnly? StartDate { get; set; }
    public DateOnly? EndDate { get; set; }

    // ids
    public int? TimesheetId { get; set; }
    public int? WorkerId { get; set; }
    public int? DefaultProjectId { get; set; }
    public int? PositionPayCycleId { get; set; }
    public int? ExceptionCriteriaId { get; set; }
    public int? InterCompanyId { get; set; }

    // csv strings passed straight through
    public string? WorkerIds { get; set; }
    public string? ProjectIds { get; set; }
    public string? TimekeeperGroupIds { get; set; }
    public string? StatusValues { get; set; }
    public string? TimesheetIds { get; set; }

    // enum (name, e.g. Approved)
    public string? TimesheetStatus { get; set; }

    // flags
    public bool? ShowAll { get; set; }
    public bool? HasExceptionCriteria { get; set; }
    public bool? IsUnionTimesheet { get; set; }
    public bool? OnPayDate { get; set; }
    public bool? ActiveInAL { get; set; }
    public bool? ExcludeDraftTimesheet { get; set; }

    // text
    public string? SearchTerm { get; set; }
    public string? ExceptionEditedByUserName { get; set; }

    // paging / sort
    public int? PageIndex { get; set; }
    public int? PageSize { get; set; }
    public string? SortProperty { get; set; }
    public string? SortDirection { get; set; }
    public string? OrderBy { get; set; }

    public IEnumerable<KeyValuePair<string, string?>> ToQueryString()
    {
        void Add(List<KeyValuePair<string, string?>> l, string k, object? v)
        {
            if (v is null) return;
            var s = v switch
            {
                DateOnly d => d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                bool b => b ? "true" : "false",
                _ => v.ToString(),
            };
            if (!string.IsNullOrWhiteSpace(s)) l.Add(new(k, s!));
        }

        var q = new List<KeyValuePair<string, string?>>();
        Add(q, "StartDate", StartDate);
        Add(q, "EndDate", EndDate);
        Add(q, "TimesheetId", TimesheetId);
        Add(q, "WorkerId", WorkerId);
        Add(q, "DefaultProjectId", DefaultProjectId);
        Add(q, "PositionPayCycleId", PositionPayCycleId);
        Add(q, "ExceptionCriteriaId", ExceptionCriteriaId);
        Add(q, "InterCompanyId", InterCompanyId);
        Add(q, "WorkerIds", WorkerIds);
        Add(q, "ProjectIds", ProjectIds);
        Add(q, "TimekeeperGroupIds", TimekeeperGroupIds);
        Add(q, "StatusValues", StatusValues);
        Add(q, "TimesheetIds", TimesheetIds);
        Add(q, "TimesheetStatus", TimesheetStatus);
        Add(q, "ShowAll", ShowAll);
        Add(q, "HasExceptionCriteria", HasExceptionCriteria);
        Add(q, "IsUnionTimesheet", IsUnionTimesheet);
        Add(q, "OnPayDate", OnPayDate);
        Add(q, "ActiveInAL", ActiveInAL);
        Add(q, "ExcludeDraftTimesheet", ExcludeDraftTimesheet);
        Add(q, "SearchTerm", SearchTerm);
        Add(q, "ExceptionEditedByUserName", ExceptionEditedByUserName);
        Add(q, "PageIndex", PageIndex);
        Add(q, "PageSize", PageSize);
        Add(q, "SortProperty", SortProperty);
        Add(q, "SortDirection", SortDirection);
        Add(q, "OrderBy", OrderBy);
        return q;
    }
}
