using System.Collections.Concurrent;
using System.Text;

namespace SIS.Adle.Mcp.Server.Logging;

/// <summary>
/// Minimal append-only file logger. Captures every log line (including the MCP SDK's
/// "tool threw an unhandled exception" entries) to logs/mcp-yyyyMMdd.log so tool calls
/// driven from the debug Swagger UI can be investigated after the fact.
/// </summary>
public sealed class FileLoggerProvider : ILoggerProvider
{
    private readonly string _dir;
    private readonly object _gate = new();
    private readonly ConcurrentDictionary<string, FileLogger> _loggers = new();

    public FileLoggerProvider(string directory)
    {
        _dir = directory;
        Directory.CreateDirectory(_dir);
    }

    public ILogger CreateLogger(string categoryName) =>
        _loggers.GetOrAdd(categoryName, name => new FileLogger(name, Write));

    private void Write(string line)
    {
        var path = Path.Combine(_dir, $"mcp-{DateTime.UtcNow:yyyyMMdd}.log");
        lock (_gate)
            File.AppendAllText(path, line, Encoding.UTF8);
    }

    public void Dispose() => _loggers.Clear();

    private sealed class FileLogger(string category, Action<string> write) : ILogger
    {
        public IDisposable BeginScope<TState>(TState state) where TState : notnull => NullScope.Instance;

        public bool IsEnabled(LogLevel logLevel) => logLevel >= LogLevel.Information;

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception,
            Func<TState, Exception?, string> formatter)
        {
            if (!IsEnabled(logLevel)) return;
            var sb = new StringBuilder()
                .Append(DateTime.UtcNow.ToString("O")).Append(" [").Append(logLevel).Append("] ")
                .Append(category).Append(" - ").Append(formatter(state, exception)).Append('\n');
            if (exception is not null)
                sb.Append(exception).Append('\n');
            write(sb.ToString());
        }

        private sealed class NullScope : IDisposable
        {
            public static readonly NullScope Instance = new();
            public void Dispose() { }
        }
    }
}
