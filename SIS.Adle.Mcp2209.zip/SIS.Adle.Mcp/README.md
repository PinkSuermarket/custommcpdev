# SIS Advanced Labor — Custom MCP Server (SSO only)

A standalone ASP.NET (`net10.0`) **remote MCP server** for GitHub Copilot, sitting beside
the `SIS-APS` solution. Its only purpose is to prove the **Single Sign-On** path against the
existing Microsoft login (Azure AD B2C). It ships a single diagnostic tool,
`get_user_details`, that echoes the signed-in user's token claims so login success is visible.

## How auth works (no re-login inside the MCP)

The MCP server is an OAuth2 **resource server**:

1. Copilot / VS Code connects to `https://<host>/mcp`.
2. Unauthenticated calls get `401` with
   `WWW-Authenticate: Bearer resource_metadata="…/.well-known/oauth-protected-resource"`.
3. Copilot reads that metadata document, discovers the B2C **authorization server**, and
   runs OAuth2 **auth-code + PKCE** itself. If the developer already has a Microsoft SSO
   session (they are signed in to Microsoft in the IDE), this round-trips with **no prompt**.
4. Copilot resends the request with `Authorization: Bearer <access token>`.
5. This server validates the token (issuer, audience, signature, lifetime) via JWT bearer
   and lets the MCP handshake through.

The MCP server never collects credentials and never starts its own login UI.

## Authentication configuration (`Mcp:Authentication`)

Values are **taken from the existing Advanced Labor API**
(`SIS-APS/src/SIS.APS.Partners.API/appsettings.Development.json` and
`SIS.APS.WebApi/appsettings.*.json`), which use **Azure AD B2C**. `appsettings.Development.json`
and `appsettings.QA.json` are pre-filled; override per environment or via
`Mcp__Authentication__Authority=…` env vars.

| Key | Dev value (from existing app) |
|---|---|
| `Scheme` | `B2C` (also supports `EntraId`; `ApiKey` reserved — see `Auth/McpAuthenticationExtensions.cs`) |
| `Authority` | `https://sisapstest.b2clogin.com/sisapstest.onmicrosoft.com/B2C_1_signin_signup/v2.0` |
| `Audience` | `91f7975d-e6e1-4e28-a57e-0dba236a37a9` |
| `ValidIssuers` | empty → issuer validated from the authority's OIDC metadata (same as SIS APS) |
| `ScopesSupported` | `https://sisapstest.onmicrosoft.com/91f7975d-…/user_impersonation` |
| `RequireHttpsMetadata` | `true` |

QA (`appsettings.QA.json`): authority `https://qasisapstest.b2clogin.com/qasisapstest.onmicrosoft.com/B2C_1_signin_signup/v2.0`, audience `ad1bf57e-cabf-4c64-b652-81511c158737`.

### App registration (one-time, Azure portal — B2C)

The MCP server validates tokens for the **same B2C API app** the Advanced Labor API uses
(`91f7975d-…`). To let Copilot obtain a token for it:

1. In the B2C tenant, on that API app's **Expose an API**, confirm the
   `user_impersonation` scope exists.
2. Pre-authorize the client app(s) Copilot uses (VS Code / Visual Studio, or a dedicated
   B2C client registration) for that scope, with redirect URIs Copilot expects.
3. Reference values (already in `appsettings.Development.json` under `Mcp:B2CReference`):
   Instance `https://sisapstest.b2clogin.com/`, Domain `sisapstest.onmicrosoft.com`,
   TenantId `d30a9e66-38ae-47a2-beb9-3b9989b9f212`, Policy `B2C_1_signin_signup`.

## Run locally

```bash
dotnet run --project src/SIS.Adle.Mcp.Server
```

Smoke test:

```bash
curl -k https://localhost:7443/healthz
curl -k https://localhost:7443/.well-known/oauth-protected-resource
curl -k -i -X POST https://localhost:7443/mcp \
  -H 'content-type: application/json' -H 'accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"c","version":"1"}}}'
# -> 401 + WWW-Authenticate with resource_metadata

# with a bearer token: initialize succeeds and tools/list returns get_user_details
curl -k -X POST https://localhost:7443/mcp -H "Authorization: Bearer $TOKEN" \
  -H 'content-type: application/json' -H 'accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"c","version":"1"}}}'
```

## Dev shortcut for Copilot Studio: `Mcp:DevToken` (ROPC)

Copilot Studio's "Add MCP server" wizard forces OAuth **dynamic client registration**,
which Azure AD B2C/Entra don't support (`GetDynamicClientRegistrationResultAsync failed`).
For local testing, let the **server** get the token instead:

```jsonc
"Mcp": {
  "DevToken": {
    "Enabled": true,                 // /mcp becomes UNAUTHENTICATED
    "TokenUrl": "https://sisapstest.b2clogin.com/sisapstest.onmicrosoft.com/B2C_1_ROPC_Auth/oauth2/v2.0/token",
    "ClientId": "91f7975d-...",       // reuse the API's CTOptions ClientId
    "Scope":    "openid https://sisapstest.onmicrosoft.com/91f7975d-.../user_impersonation offline_access",
    "UserId":   "dev-user@...",       // put real values in user-secrets / env vars
    "Password": "..."
  }
}
```

The server does an OAuth2 **password grant** (same request as
`SIS.APS.Core/.../C365Field/C365FieldTokenService.GetAccessTokenAsync`), caches the token
until ~1 min before expiry, and `get_user_details` returns that token's claims with
`"source": "dev-ropc-token"`.

Then in Copilot Studio add the MCP server with **Authentication = None** and URL
`https://<tunnel>/mcp` — no OAuth, no client registration. Set values via user-secrets:

```bash
cd src/SIS.Adle.Mcp.Server
dotnet user-secrets set "Mcp:DevToken:Enabled" "true"
dotnet user-secrets set "Mcp:DevToken:UserId" "dev-user@sisapstest.onmicrosoft.com"
dotnet user-secrets set "Mcp:DevToken:Password" "..."
```

Needs a B2C **ROPC** user-flow policy (`B2C_1_ROPC_*`) for `TokenUrl`. **Never enable this
outside local dev** — it disables auth on `/mcp` and ships credentials in config.

## Diagnostic tool: `get_user_details`

The server exposes exactly one tool. It reads the **validated** access-token claims off
the current request and returns them — name, `oid`/`sub`, `emails`, `tid`, `idp`, user flow
(`tfp`), `scp`, `iss`, `aud`, and the full claim set. If the call reaches it, SSO worked.

In Copilot chat: *"call get_user_details"* → you should see your Microsoft account back.
Unauthenticated callers never reach the tool (the `/mcp` endpoint requires auth first).

## Expose localhost to Copilot with ngrok

Copilot connects to a public HTTPS URL, so the OAuth **resource** must be that same URL.

```bash
# 1. run the server
dotnet run --project src/SIS.Adle.Mcp.Server

# 2. tunnel 7443 (TLS terminates at ngrok; forward to the http port to avoid double-TLS)
ngrok http https://localhost:7443    # or: ngrok http 5443

# 3. take the https forwarding URL, e.g. https://abcd-1234.ngrok-free.app, and point the
#    server's advertised resource at it (env var overrides appsettings):
Mcp__ServerUrl=https://abcd-1234.ngrok-free.app dotnet run --project src/SIS.Adle.Mcp.Server
```

`Program.cs` already honours `X-Forwarded-Proto/Host` from the tunnel. Verify:

```bash
curl https://abcd-1234.ngrok-free.app/.well-known/oauth-protected-resource
# "resource" must equal the ngrok URL
```

Then register that URL with Copilot (`.vscode/mcp.json`):

```jsonc
{ "servers": { "sis-adle": { "type": "http", "url": "https://abcd-1234.ngrok-free.app/mcp" } } }
```

Start the server from the MCP view → Copilot runs the B2C login (silent if you already have
a Microsoft SSO session) → server shows **Connected, 1 tool**. Add the ngrok URL +
`https://vscode.dev/redirect` / `http://localhost` as redirect URIs on the B2C client app
if the login redirect is rejected.

## Project layout

```
src/SIS.Adle.Mcp.Server/
  Program.cs                          # host wiring; AddMcpServer().WithHttpTransport().WithTools<UserTools>()
  Auth/McpAuthenticationOptions.cs    # typed Mcp:Authentication options + McpAuthScheme enum
  Auth/McpAuthenticationExtensions.cs # AddMcpAuthentication() — scheme switch, JwtBearer + AddMcp metadata
  Tools/UserTools.cs                  # get_user_details — echoes validated token claims
```

## Not in this iteration

- MCP tools calling the Advanced Labor API (`SIS-APS/src/SIS.APS.Partners.API`) via
  on-behalf-of / token pass-through. `get_user_details` only reads the token, it calls nothing.
- `ApiKey` scheme (the `switch` in `McpAuthenticationExtensions` is where it goes).
- Deployment pipeline / container image.
