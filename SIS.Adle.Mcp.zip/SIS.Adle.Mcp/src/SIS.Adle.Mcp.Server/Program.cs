using Microsoft.AspNetCore.HttpOverrides;
using SIS.Adle.Mcp.Server.Api;
using SIS.Adle.Mcp.Server.Auth;
using SIS.Adle.Mcp.Server.Logging;
using SIS.Adle.Mcp.Server.Tools;

var builder = WebApplication.CreateBuilder(args);

// Append every log line to logs/mcp-yyyyMMdd.log (captures MCP tool exceptions).
builder.Logging.AddProvider(new FileLoggerProvider(Path.Combine(builder.Environment.ContentRootPath, "logs")));

// Trust the X-Forwarded-* headers from a local tunnel (ngrok) so the scheme/host
// seen by the app is the public https URL, not http://localhost.
builder.Services.Configure<ForwardedHeadersOptions>(o =>
{
    o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto | ForwardedHeaders.XForwardedHost;
    o.KnownIPNetworks.Clear();
    o.KnownProxies.Clear();
});

// --- Authentication (Single Sign-On) ----------------------------------------
// See Auth/McpAuthenticationExtensions.cs. The scheme is chosen from the
// "Mcp:Authentication:Scheme" config value; v1 supports "B2C" (default, matches
// the existing Advanced Labor API) and "EntraId".
builder.AddMcpAuthentication();

builder.Services.AddHttpContextAccessor();

// DEV token path (Mcp:DevToken). Server fetches its own bearer via OAuth2 password
// grant so Copilot Studio can connect with Authentication = None.
builder.Services.AddHttpClient<IDevTokenService, DevTokenService>();

// Typed client for the downstream Advanced Labor Web API (tools call this).
builder.Services.AddHttpClient<AdvancedLaborClient>((sp, c) =>
{
    var baseUrl = sp.GetRequiredService<IConfiguration>().GetValue<string>("Mcp:AdvancedLaborApi:BaseUrl")
        ?? "https://dev-al-api.azurewebsites.net/";
    c.BaseAddress = new Uri(baseUrl.EndsWith('/') ? baseUrl : baseUrl + "/");
});

var devTokenEnabled = builder.Configuration.GetValue<bool>("Mcp:DevToken:Enabled");

// Debug HTTP surface: Swagger UI to drive the tools by hand and see full errors.
builder.Services.AddScoped<UserTools>();
builder.Services.AddScoped<TimesheetHourlyCostsTool>();
builder.Services.AddScoped<TimesheetFringesCostsTool>();
builder.Services.AddScoped<TimesheetDeductionsCostsTool>();
builder.Services.AddScoped<TimesheetErContributionsCostsTool>();
builder.Services.AddScoped<TimesheetCostsSummaryTool>();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o => o.SwaggerDoc("v1", new() { Title = "SIS Advanced Labor MCP — debug", Version = "v1" }));

// --- MCP server -----------------------------------------------------------
// Streamable HTTP transport. One diagnostic tool only: get_user_details, which
// echoes the caller's token claims so login success can be verified end to end.
builder.Services
    .AddMcpServer(o =>
    {
        o.ServerInfo = new() { Name = "SIS Advanced Labor MCP", Version = "0.1.0" };
    })
    .WithHttpTransport()
    .WithTools<UserTools>()
    .WithTools<TimesheetHourlyCostsTool>()
    .WithTools<TimesheetFringesCostsTool>()
    .WithTools<TimesheetDeductionsCostsTool>()
    .WithTools<TimesheetErContributionsCostsTool>()
    .WithTools<TimesheetCostsSummaryTool>();

var app = builder.Build();

app.UseForwardedHeaders();

// Debug Swagger UI at /swagger (drives the tools, shows full errors).
app.UseSwagger();
app.UseSwaggerUI(o =>
{
    o.SwaggerEndpoint("/swagger/v1/swagger.json", "debug v1");
    o.DocumentTitle = "SIS Advanced Labor MCP — debug";
});

app.UseAuthentication();
app.UseAuthorization();

// Unauthenticated liveness probe.
app.MapGet("/healthz", () => Results.Ok("ok")).AllowAnonymous();

app.MapControllers();

// MCP endpoint. Normally requires a valid access token (+ serves
// /.well-known/oauth-protected-resource). When Mcp:DevToken:Enabled is true the
// endpoint is open and the server supplies the identity itself via ROPC.
var mcp = app.MapMcp("/mcp");
if (devTokenEnabled)
{
    app.Logger.LogWarning("Mcp:DevToken:Enabled = true — /mcp is UNAUTHENTICATED and uses hard-coded dev credentials. Do not use outside local dev.");
    mcp.AllowAnonymous();
}
else
{
    mcp.RequireAuthorization();
}

app.Run();
