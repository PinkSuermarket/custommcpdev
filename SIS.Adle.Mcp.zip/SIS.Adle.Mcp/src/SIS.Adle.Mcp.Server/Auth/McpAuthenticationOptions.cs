namespace SIS.Adle.Mcp.Server.Auth;

/// <summary>
/// Supported authentication schemes for the MCP server.
/// v1 implements <see cref="B2C"/> and <see cref="EntraId"/> (same JWT bearer wiring,
/// different authority). <see cref="ApiKey"/> is an extension point for a later iteration.
/// The existing Advanced Labor API (SIS.APS.Partners.API) uses Azure AD <see cref="B2C"/>.
/// </summary>
public enum McpAuthScheme
{
    /// <summary>Azure AD B2C user-flow authority — matches the existing SIS APS APIs.</summary>
    B2C = 0,
    /// <summary>Microsoft Entra ID (workforce tenant) authority.</summary>
    EntraId = 1,
    /// <summary>Static / developer API key. Not implemented in v1.</summary>
    ApiKey = 2,
}

/// <summary>
/// Strongly-typed view of the <c>Mcp</c> configuration section.
/// Bound in <see cref="McpAuthenticationExtensions.AddMcpAuthentication"/>.
/// </summary>
public sealed class McpServerOptions
{
    public const string SectionName = "Mcp";

    /// <summary>Public base URL this server is reachable at (used in the resource metadata document).</summary>
    public string ServerUrl { get; set; } = "https://localhost:7443";

    public McpAuthenticationOptions Authentication { get; set; } = new();

    /// <summary>Downstream Advanced Labor API the tools call. Bound from <c>Mcp:AdvancedLaborApi</c>.</summary>
    public AdvancedLaborApiOptions AdvancedLaborApi { get; set; } = new();

    /// <summary>
    /// DEV ONLY. When enabled, the server fetches its own bearer token via OAuth2
    /// password grant (ROPC) using hard-coded dev credentials — mirrors
    /// <c>C365FieldTokenService.GetAccessTokenAsync</c> in SIS.APS.Core. Lets Copilot
    /// Studio add the MCP server with Authentication = None (no OAuth handshake, no
    /// dynamic client registration) while tools still act as a signed-in user.
    /// </summary>
    public DevTokenOptions DevToken { get; set; } = new();
}

public sealed class AdvancedLaborApiOptions
{
    /// <summary>Base URL of the Advanced Labor Web API (trailing slash optional).</summary>
    public string BaseUrl { get; set; } = "https://dev-al-api.azurewebsites.net/";

    /// <summary>Optional fallback for the <c>x-company</c> header when a tool call omits companyId.</summary>
    public int? DefaultCompanyId { get; set; }
}

public sealed class DevTokenOptions
{
    /// <summary>Master switch. Keep <c>false</c> outside local development.</summary>
    public bool Enabled { get; set; }

    /// <summary>
    /// Optional. A bearer token pasted in directly (e.g. copied from SIS APS Swagger after
    /// logging in). When set, it is used as-is and the ROPC fields below are ignored —
    /// the reliable path when the account is federated / MFA and ROPC can't be used.
    /// </summary>
    public string StaticToken { get; set; } = string.Empty;

    /// <summary>OAuth2 token endpoint (a B2C ROPC policy, e.g. .../B2C_1_ROPC_Auth/oauth2/v2.0/token).</summary>
    public string TokenUrl { get; set; } = string.Empty;

    public string ClientId { get; set; } = string.Empty;
    public string Scope { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

public sealed class McpAuthenticationOptions
{
    /// <summary>Which auth scheme to wire: <c>B2C</c> or <c>EntraId</c> in v1.</summary>
    public McpAuthScheme Scheme { get; set; } = McpAuthScheme.B2C;

    /// <summary>
    /// OIDC authority. For B2C this is the user-flow authority, e.g.
    /// https://&lt;tenant&gt;.b2clogin.com/&lt;tenant&gt;.onmicrosoft.com/B2C_1_signin_signup/v2.0
    /// </summary>
    public string Authority { get; set; } = string.Empty;

    /// <summary>Expected token audience (the API app's client id / Application ID URI).</summary>
    public string Audience { get; set; } = string.Empty;

    /// <summary>Accepted issuers. Left empty => issuer is validated from the authority's OIDC metadata.</summary>
    public string[] ValidIssuers { get; set; } = [];

    /// <summary>OAuth scopes advertised in the protected-resource metadata document.</summary>
    public string[] ScopesSupported { get; set; } = [];

    public bool RequireHttpsMetadata { get; set; } = true;
}
