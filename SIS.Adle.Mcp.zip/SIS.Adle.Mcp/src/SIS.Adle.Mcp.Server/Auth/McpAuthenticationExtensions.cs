using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using ModelContextProtocol.AspNetCore.Authentication;
using ModelContextProtocol.Authentication;

namespace SIS.Adle.Mcp.Server.Auth;

/// <summary>
/// Single entry point for MCP server authentication.
///
/// The MCP server acts as an OAuth2 <b>resource server</b>: it validates the access token
/// that the MCP client (GitHub Copilot / VS Code) already obtained from the Microsoft login
/// (Azure AD B2C or Entra ID), and it publishes an RFC 9728 "protected resource metadata"
/// document so the client can discover the authorization server and run auth-code + PKCE
/// itself. When the developer already has a Microsoft SSO session the round-trip completes
/// with no extra prompt — the "cannot re-authenticate inside the MCP" requirement.
///
/// The JWT bearer wiring is identical for <see cref="McpAuthScheme.B2C"/> and
/// <see cref="McpAuthScheme.EntraId"/> (only the authority differs), and mirrors
/// <c>SIS.APS.Partners.API/Configuration/ServiceCollectionExtensions.cs</c> so behaviour
/// matches the existing Advanced Labor API. <see cref="McpAuthScheme.ApiKey"/> is the
/// extension point for a later iteration.
/// </summary>
public static class McpAuthenticationExtensions
{
    public static WebApplicationBuilder AddMcpAuthentication(this WebApplicationBuilder builder)
    {
        var options = new McpServerOptions();
        builder.Configuration.GetSection(McpServerOptions.SectionName).Bind(options);
        builder.Services.Configure<McpServerOptions>(
            builder.Configuration.GetSection(McpServerOptions.SectionName));

        var auth = options.Authentication;

        switch (auth.Scheme)
        {
            case McpAuthScheme.B2C:
            case McpAuthScheme.EntraId:
                AddJwtBearerOidc(builder, options);
                break;

            // Extension point for a later iteration — intentionally not implemented in v1.
            case McpAuthScheme.ApiKey:
            default:
                throw new NotSupportedException(
                    $"Mcp:Authentication:Scheme '{auth.Scheme}' is not supported yet. Use 'B2C' or 'EntraId'.");
        }

        builder.Services.AddAuthorization(o =>
        {
            o.FallbackPolicy = o.DefaultPolicy; // every endpoint requires an authenticated caller unless it opts out
        });

        return builder;
    }

    private static void AddJwtBearerOidc(WebApplicationBuilder builder, McpServerOptions options)
    {
        var auth = options.Authentication;

        if (string.IsNullOrWhiteSpace(auth.Authority))
            throw new InvalidOperationException($"Mcp:Authentication:Authority is required for the {auth.Scheme} scheme.");
        if (string.IsNullOrWhiteSpace(auth.Audience))
            throw new InvalidOperationException($"Mcp:Authentication:Audience is required for the {auth.Scheme} scheme.");

        builder.Services
            .AddAuthentication(o =>
            {
                o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                // Challenges go through the MCP handler so 401s carry the
                // WWW-Authenticate: Bearer resource_metadata="..." hint.
                o.DefaultChallengeScheme = McpAuthenticationDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(o =>
            {
                o.Authority = auth.Authority;
                o.Audience = auth.Audience;
                o.RequireHttpsMetadata = auth.RequireHttpsMetadata;
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = true,
                    ValidAudiences = [auth.Audience],
                    // When ValidIssuers is left empty the issuer is validated against the
                    // value published in the authority's OIDC metadata (same as the
                    // existing SIS APS APIs). Set it explicitly to pin issuers.
                    ValidateIssuer = true,
                    ValidIssuers = auth.ValidIssuers is { Length: > 0 } ? auth.ValidIssuers : null,
                    ValidateIssuerSigningKey = true,
                    RequireExpirationTime = true,
                    ValidateLifetime = true,
                    RequireSignedTokens = true,
                };
            })
            .AddMcp(o =>
            {
                o.ResourceMetadata = new ProtectedResourceMetadata
                {
                    Resource = options.ServerUrl,
                    AuthorizationServers = { auth.Authority },
                };

                foreach (var scope in auth.ScopesSupported)
                    o.ResourceMetadata.ScopesSupported.Add(scope);
            });
    }
}
